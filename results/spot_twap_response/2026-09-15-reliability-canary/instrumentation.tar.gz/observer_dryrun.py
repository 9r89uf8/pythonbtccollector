import json
from pathlib import Path
import subprocess

remote=r'''
import json,pathlib,subprocess,time
root=pathlib.Path('/opt/price-collector')
env=pathlib.Path('/etc/price-collector/collector.env').read_text().splitlines()
assert 'GHOST_TWAP_ENABLED=false' in env
start=time.time_ns()//1000000+1000
name='ghost-reliability-observer-dry-'+str(start)
directory=pathlib.Path('/var/lib/price-collector')/name
args=['systemd-run','--unit='+name,'--collect','--property=User=pricecollector',
 '--property=WorkingDirectory=/opt/price-collector','--property=RuntimeMaxSec=15s',
 '--property=TimeoutStopSec=10s',str(root/'.venv/bin/python'),'-m','price_collector.ghost_twap_observer',
 'observe','--start-ms',str(start),'--output-directory',str(directory)]
subprocess.run(args,check=True,capture_output=True,timeout=10)
deadline=time.monotonic()+35
while not (directory/'manifest.json').exists() and time.monotonic()<deadline:
    time.sleep(.5)
assert (directory/'ready.json').exists()
manifest=json.loads((directory/'manifest.json').read_bytes())
assert manifest['status']=='incomplete' and manifest['reason']=='interrupted'
analysis=json.loads(subprocess.check_output(['sudo','-u','pricecollector',str(root/'.venv/bin/python'),
 '-m','price_collector.ghost_twap_observer','analyze','--directory',str(directory)],cwd=root,timeout=10))
assert not analysis['observed_run_ids']
assert analysis['full_hour']['statuses'].get('present',0)==0
subprocess.run(['systemctl','reset-failed',name+'.service'],capture_output=True,timeout=10)
print(json.dumps(dict(unit=name,directory=str(directory),command=args,manifest=manifest,
 read_latency=analysis['read_latency'],statuses=analysis['full_hour']['statuses'],
 qualification='Interrupted 15-second disabled-producer readiness check, not a completed coverage measurement.'),indent=2))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=20','root@152.42.247.86','python3 -'],input=remote.encode(),capture_output=True,timeout=60)
if p.returncode:raise SystemExit(p.stderr.decode())
value=json.loads(p.stdout)
output=Path('results/spot_twap_response/2026-09-15-reliability-canary/OBSERVER_DRY_RUN.json')
assert not output.exists()
output.write_bytes(p.stdout)
print(json.dumps({k:value[k] for k in ('unit','directory','read_latency','statuses')},indent=2))
