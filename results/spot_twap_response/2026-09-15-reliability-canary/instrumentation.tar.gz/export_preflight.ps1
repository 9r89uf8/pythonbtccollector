$ErrorActionPreference = 'Stop'
$artifactDirectory = Split-Path -Parent $PSCommandPath
foreach ($name in @('browser.jsonl', 'campaign.json')) {
    $target = Join-Path $artifactDirectory $name
    if (Test-Path -LiteralPath $target) {
        throw "Refusing to overwrite existing capture artifact: $target"
    }
}
Write-Output 'Both export destinations are unused. Invoke browser_export.js once.'
