"""One authorized campaign; scheduled stop executes the installed repo module."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/spot_twap_response/2026-09-15-reliability-canary'
expected=json.loads((OUT/'PREFLIGHT.json').read_text())['expected']
expected['commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not (OUT/'LAUNCH.json').exists()
remote=r'''
import datetime,hashlib,json,os,pathlib,pwd,shutil,stat,subprocess,tempfile,time
E=EXPECTED_JSON
root=pathlib.Path('/opt/price-collector'); base=pathlib.Path('/var/lib/price-collector')
os.chdir(root)
def run(args,timeout=20):
    return subprocess.run(args,check=True,capture_output=True,text=True,timeout=timeout).stdout.strip()
def save(path,value):
    with path.open('x') as f:
        json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
env=pathlib.Path('/etc/price-collector/collector.env')
assert not env.is_symlink()
raw=env.read_bytes(); info=env.stat(); lines=raw.splitlines(keepends=True)
def values(raw):
    return dict(line.decode().strip().split('=',1) for line in raw.splitlines() if line and not line.startswith(b'#') and b'=' in line)
v=values(raw)
assert v['GHOST_TWAP_ENABLED']=='false'
assert v['GHOST_TWAP_STATE_DIRECTORY']==E['state_directory']
assert v['GHOST_TWAP_SOURCE_MAX_AGE_MS']=='5000' and v['GHOST_TWAP_RECEIPT_MAX_AGE_MS']=='3000'
assert run(['sudo','-u','pricecollector','git','rev-parse','HEAD'])==E['commit']
assert run(['sudo','-u','pricecollector','git','status','--porcelain'])==''
assert run(['redis-cli','EXISTS','btc:live:ghost_chainlink_twap_60s'])=='0'
assert not list(pathlib.Path(v['GHOST_TWAP_STATE_DIRECTORY']).glob('*.row'))
for name,digest in E['campaign_hashes'].items():
    assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest
status=json.loads(run(['sudo','-u','postgres',str(root/'.venv/bin/python'),'-m','price_collector.ghost_twap_admin','status']))
assert status['row_count']==E['row_count'] and status['incomplete_count']==0
assert status['measurement']['relation_bytes']<1536*1024**2
assert shutil.disk_usage('/var/lib/postgresql').free>10*1024**3
for name in ['price-collector','price-collector-polymarket-chainlink','price-collector-binance-futures',
             'price-collector-polymarket-probabilities','price-api','redis-server']:
    assert run(['systemctl','is-active',name])=='active'
start=(time.time_ns()//1000000000+25)*1000
end=start+3600000
stamp=datetime.datetime.fromtimestamp(start//1000,datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
state=base/('ghost-reliability-'+stamp)
control=base/('ghost-reliability-control-'+stamp)
observer=base/('ghost-reliability-observer-'+stamp)
for p in (state,control,observer):assert not p.exists()
state.mkdir(mode=0o700); control.mkdir(mode=0o700)
owner=pwd.getpwnam('pricecollector'); os.chown(state,owner.pw_uid,owner.pw_gid)
stopunit='ghost-reliability-stop-'+stamp.lower()
observeunit='ghost-reliability-observer-'+stamp.lower()
calendar=datetime.datetime.fromtimestamp(end//1000,datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
stopcommand=[str(root/'.venv/bin/python'),'-m','price_collector.ghost_twap_canary_stop',
 '--expected-state',str(state),'--output',str(control/'stop.json')]
timer=['systemd-run','--unit='+stopunit,'--on-calendar='+calendar,'--timer-property=AccuracySec=1s',
 '--collect','--property=WorkingDirectory=/opt/price-collector','--property=TimeoutStartSec=180s',*stopcommand]
observe=['systemd-run','--unit='+observeunit,'--collect','--property=User=pricecollector',
 '--property=WorkingDirectory=/opt/price-collector','--property=RuntimeMaxSec=3660s',
 '--property=TimeoutStopSec=10s',str(root/'.venv/bin/python'),'-m','price_collector.ghost_twap_observer',
 'observe','--start-ms',str(start),'--output-directory',str(observer)]
record=dict(version=1,status='preparing',campaign_start_ms=start,campaign_end_ms=end,commit=E['commit'],
 state_directory=str(state),control_directory=str(control),observer_directory=str(observer),
 stop_unit=stopunit,observer_unit=observeunit,stop_command=stopcommand,
 stop_timer_command=timer,observer_command=observe,previous_state_directory=E['state_directory'],
 previous_campaign_hashes=E['campaign_hashes'],prelaunch_audit_rows=status['row_count'],
 prelaunch_relation_bytes=status['measurement']['relation_bytes'],
 source_max_age_ms=5000,receipt_max_age_ms=3000,producer_duration_ms=3600000,
 browser_session='ghost-reliability-canary',browser_origin='http://127.0.0.1:19016',
 helper_sha256=hashlib.sha256((root/'price_collector/ghost_twap_canary_stop.py').read_bytes()).hexdigest())
save(control/'prepared.json',record)
try:
    run(timer)
    assert run(['systemctl','is-active',stopunit+'.timer'])=='active'
    run(observe)
    deadline=time.monotonic()+12
    while not (observer/'ready.json').exists() and time.monotonic()<deadline:time.sleep(.1)
    ready=json.loads((observer/'ready.json').read_bytes())
    assert ready['start_ms']==start and ready['end_ms']==end
    assert int(ready['ready_wall_ns'])//1000000<start
    wait_deadline=time.monotonic()+35
    while time.time_ns()//1000000<start and time.monotonic()<wait_deadline:time.sleep(.05)
    assert time.time_ns()//1000000>=start,'activation clock did not reach fixed start'
    assert time.time_ns()//1000000-start<3000
    assert env.read_bytes()==raw,'configuration changed before activation'
    change={'GHOST_TWAP_ENABLED':'true','GHOST_TWAP_STATE_DIRECTORY':str(state),'GHOST_TWAP_CANARY_START_MS':str(start)}
    updated=[]
    for key in change:assert sum(line.startswith((key+'=').encode()) for line in lines)==1
    for line in lines:
        key=line.split(b'=',1)[0].decode()
        if key in change:
            ending=b'\r\n' if line.endswith(b'\r\n') else b'\n' if line.endswith(b'\n') else b''
            line=(key+'='+change[key]).encode()+ending
        updated.append(line)
    fd,tmp=tempfile.mkstemp(prefix='.ghost-canary-',dir=env.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            os.fchown(f.fileno(),info.st_uid,info.st_gid);os.fchmod(f.fileno(),stat.S_IMODE(info.st_mode))
            f.write(b''.join(updated));f.flush();os.fsync(f.fileno())
        assert env.read_bytes()==raw
        os.replace(tmp,env)
        d=os.open(env.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(d)
        finally:os.close(d)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    record['activation_requested_wall_ns']=str(time.time_ns())
    run(['systemctl','restart','price-collector-polymarket-chainlink'],timeout=150)
    assert run(['systemctl','is-active','price-collector-polymarket-chainlink'])=='active'
    record.update(status='started',activation_completed_wall_ns=str(time.time_ns()),observer_ready=ready,
      collector_pid=int(run(['systemctl','show','price-collector-polymarket-chainlink','--property=MainPID','--value'])),
      timer_next_elapse=run(['systemctl','show',stopunit+'.timer','--property=NextElapseUSecRealtime','--value']))
    save(control/'launch.json',record)
except BaseException as exc:
    record.update(status='launch_failed',error_type=type(exc).__name__)
    record['cleanup']={}
    try:
        nowvalues=values(env.read_bytes())
        if nowvalues.get('GHOST_TWAP_STATE_DIRECTORY')==str(state):
            cleanup=subprocess.run(stopcommand,timeout=175,check=False,capture_output=True)
            record['cleanup']['matching_stop_returncode']=cleanup.returncode
    except BaseException as cleanup_error:
        record['cleanup']['matching_stop_error_type']=type(cleanup_error).__name__
    for unit in (observeunit+'.service',stopunit+'.timer'):
        try:
            # Keep the timer as a backstop if disabling the matching campaign
            # could not be confirmed. Never extend or repoint that timer.
            nowvalues=values(env.read_bytes())
            if unit.endswith('.timer') and nowvalues.get('GHOST_TWAP_STATE_DIRECTORY')==str(state) and nowvalues.get('GHOST_TWAP_ENABLED')!='false':
                record['cleanup'][unit]='retained_as_backstop';continue
            cleanup=subprocess.run(['systemctl','stop',unit],capture_output=True,timeout=20)
            record['cleanup'][unit]=cleanup.returncode
        except BaseException as cleanup_error:
            record['cleanup'][unit]=type(cleanup_error).__name__
    save(control/'launch-failed.json',record)
    print(json.dumps(record));raise
print(json.dumps(record,indent=2))
'''.replace('EXPECTED_JSON',repr(expected))
try:
    p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=20','root@152.42.247.86','python3 -'],input=remote.encode(),capture_output=True,timeout=480)
except subprocess.TimeoutExpired as exc:
    (OUT/'LAUNCH_TIMEOUT_STDOUT.txt').write_bytes(exc.stdout or b'')
    (OUT/'LAUNCH_TIMEOUT_STDERR.txt').write_bytes(exc.stderr or b'')
    raise SystemExit('Launch orchestration timed out; investigate the armed timer/current state before any retry') from None
if p.returncode:
    (OUT/'LAUNCH_FAILURE.txt').write_bytes(p.stdout+p.stderr)
    raise SystemExit('Launch failed; exact output retained locally for review')
record=json.loads(p.stdout)
record['local_orchestration_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
record['remote_orchestration_sha256']=hashlib.sha256(remote.encode()).hexdigest()
(OUT/'LAUNCH.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
