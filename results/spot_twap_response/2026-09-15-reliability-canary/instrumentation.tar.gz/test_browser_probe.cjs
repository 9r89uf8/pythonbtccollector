// Pure mocked clocks/timers: no browser, HTTP request or production access.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'browser_probe.js'),'utf8');

async function harness() {
  let now=0, serial=0;
  const timers=new Map();
  const context=vm.createContext({
    window:{},location:{origin:'http://mock.invalid'},performance:{now:()=>now},Date,
    TextEncoder,BigInt,Set,AbortController,
    EventSource:class { addEventListener() {} close() {} },
    fetch:(_,options)=>new Promise((resolve,reject)=>{
      options.signal.addEventListener('abort',()=>reject(new Error('mock request aborted')),{once:true});
    }),
    setTimeout:(fn,delay)=>{ const id=++serial; timers.set(id,{fn,due:now+delay,interval:false}); return id; },
    clearTimeout:id=>timers.delete(id),
    setInterval:(fn,delay)=>{ const id=++serial; timers.set(id,{fn,due:now+delay,interval:true}); return id; },
    clearInterval:id=>timers.delete(id),
  });
  const fn=vm.runInContext('('+source+')',context);
  await fn({evaluate:cb=>cb()});
  const state=context.window.ghostProbe;
  const findSample=()=>[...timers.entries()].find(([,t])=>t.fn.name==='sample');
  function fire(id,at) { const timer=timers.get(id); assert(timer); timers.delete(id); now=at; timer.fn(); }
  return {state,timers,findSample,fire,setNow:value=>{now=value;},
          probes:()=>state.records.filter(r=>r.kind==='probe')};
}

(async()=>{
  const h=await harness();
  assert.equal(h.probes().length,1); assert.equal(h.probes()[0].planned_index,0);
  // Every tick first arrives early, then exactly at its grid boundary.
  for(let index=1;index<40;index++) {
    h.fire(h.findSample()[0],index*100-.4);
    assert.equal(h.probes().length,index);
    assert(h.findSample()[1].due>index*100-.4);
    h.fire(h.findSample()[0],index*100);
    assert.equal(h.probes().length,index+1);
  }
  assert.deepEqual(Array.from(h.probes(),r=>r.planned_index),Array.from({length:40},(_,i)=>i));
  // A delayed callback skips elapsed bins rather than backfilling observations.
  h.fire(h.findSample()[0],4550);
  assert.equal(h.probes().length,41); assert.equal(h.probes().at(-1).planned_index,45);
  assert.equal(new Set(h.probes().map(r=>r.planned_index)).size,h.probes().length);

  const total=h.state.observation_ms+h.state.drain_ms;
  const finish=[...h.timers.entries()].find(([,t])=>t.due===total+100);
  assert(finish);
  h.fire(finish[0],total-.5); // Deliberately deliver the finish callback early.
  assert.equal(h.state.done,false); assert.equal(h.state.records.some(r=>r.kind==='end'),false);
  const retry=[...h.timers.entries()].find(([,t])=>t.due>=total && t.due<=total+1);
  assert(retry);
  h.fire(retry[0],total);
  await Promise.resolve(); await Promise.resolve();
  assert.equal(h.state.done,true);
  assert.equal(h.state.records.at(-1).kind,'end');
  assert.equal(h.state.records.at(-1).complete,true);
  assert(h.state.records.at(-1).browser_ms-h.state.start_ms>=total);
  assert.equal(h.timers.size,0);
  console.log(JSON.stringify({status:'passed',four_second_bins:40,duplicate_indices:0,
    skipped_indices:[40,41,42,43,44],early_completion_rejected:true}));
})().catch(error=>{console.error(error);process.exitCode=1;});
