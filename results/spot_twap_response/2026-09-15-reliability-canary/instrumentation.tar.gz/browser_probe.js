async (page) => {
  return await page.evaluate(() => {
    if (window.ghostProbe) throw Error('existing capture must be exported before a fresh page is used');
    const observation = 3600000, drain = 120000, start = performance.now();
    const maxRecords = 100000, maxBytes = 128 * 1024 * 1024, reserveBytes = 8192;
    const encoder = new TextEncoder();
    const state = {records: [], done: false, latest: null, offsetLower: null, offsetUpper: null,
      latestAnchor: null, badCalibration: false, getBusy: false, pending: new Set(),
      bytes: 0, campaignMetadata: [], campaign: null, firstCampaignObject: null, lastRecordedIndex: -1,
      observation_ms: observation, drain_ms: drain, start_ms: start};
    window.ghostProbe = state;
    let source, snapshotTimer, probeTimer, finishTimer;
    const ns = t => BigInt(Math.round(t * 1000000));
    function finish(reason) {
      if (state.done) return;
      if (reason === 'completed' && performance.now()-start < observation+drain) {
        clearTimeout(finishTimer);
        finishTimer=setTimeout(() => finish('completed'),
          Math.max(1,start+observation+drain-performance.now()));
        return;
      }
      state.done = true;
      if (source) source.close();
      clearInterval(snapshotTimer); clearTimeout(probeTimer); clearTimeout(finishTimer);
      for (const controller of state.pending) controller.abort();
      const end = {kind:'end', browser_ms:performance.now(), wall_ms:Date.now(), reason,
        complete: reason === 'completed', campaign:state.campaign,
        first_campaign_object:state.firstCampaignObject, campaign_metadata_records:state.campaignMetadata.length,
        records_before_end:state.records.length, bytes_before_end:state.bytes};
      state.records.push(end);
      state.bytes += encoder.encode(JSON.stringify(end)).length + 1;
    }
    function record(kind, fields={}, at=performance.now()) {
      if (state.done) return false;
      if (at-start >= observation+drain) { finish('completed'); return false; }
      const row = {kind, browser_ms:at, ...fields};
      const size = encoder.encode(JSON.stringify(row)).length + 1;
      if (state.records.length >= maxRecords-1 || state.bytes+size > maxBytes-reserveBytes) {
        finish('capture_cap'); return false;
      }
      state.records.push(row); state.bytes += size;
      return true;
    }
    function matchingCampaign(p) {
      const c=state.campaign;
      if (!c || !p || p.runtime_version !== 'ghost-canary-v6' || p.contract_version !== 4) return false;
      if (c.run_id !== null && p.run_id !== c.run_id) return false;
      try {
        const decision=BigInt(p.decision_wall_ns);
        return decision >= BigInt(c.start_ms)*1000000n && decision < BigInt(c.end_ms)*1000000n;
      } catch (_) { return false; }
    }
    function considerCampaign(envelope, at) {
      if (state.firstCampaignObject === null && matchingCampaign(envelope.ghost))
        state.firstCampaignObject={browser_ms:at, run_id:envelope.ghost.run_id,
          decision_id:envelope.ghost.decision_id, qualification:'provisional_until_audit_join'};
    }
    // Attaching operator metadata never edits earlier capture rows. Calling
    // without run_id is provisional; a later identical start may confirm it.
    state.setCampaign = (startMs, runId=null) => {
      if (state.done) throw Error('capture already finalized');
      if (!Number.isSafeInteger(startMs) || startMs <= 0 ||
          (runId !== null && (typeof runId !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(runId))))
        throw Error('invalid campaign metadata');
      if (state.campaign && (state.campaign.start_ms !== startMs ||
          (state.campaign.run_id !== null && state.campaign.run_id !== runId)))
        throw Error('campaign identity cannot be replaced');
      if (state.campaign && state.campaign.run_id === runId) return state.campaign;
      state.campaign={start_ms:startMs, end_ms:startMs+3600000, run_id:runId};
      state.campaignMetadata.push({kind:'campaign', browser_ms:performance.now(), ...state.campaign});
      state.firstCampaignObject=null;
      for (const row of state.records) {
        if (row.kind !== 'ghost') continue;
        try { considerCampaign(JSON.parse(row.data), row.browser_ms); } catch (_) {}
        if (state.firstCampaignObject !== null) break;
      }
      return state.campaign;
    };
    state.finish = () => finish('operator_interrupted');
    record('start', {observation_ms:observation, drain_ms:drain, wall_ms:Date.now(),
      probe_version:'ghost-reliability-browser-v1', sample_interval_ms:100,
      sample_through_drain:true, max_records:maxRecords, max_bytes:maxBytes,
      campaign_metadata:'separate append-only sidecar', additional_load:false}, start);
    source = new EventSource('/forecasts/chainlink-twap/stream');
    source.addEventListener('open', () => record('open'));
    source.addEventListener('error', () => record('error', {reason:'eventsource_error', ready_state:source.readyState}));
    source.addEventListener('ghost', event => {
      const received=performance.now();
      if (!record('ghost', {data:event.data}, received)) return;
      let envelope;
      try { envelope=JSON.parse(event.data); }
      catch (error) { state.latest=null; record('error',{reason:'invalid_envelope',message:String(error)}); return; }
      if (!envelope || !envelope.api) { state.latest=null; record('error',{reason:'invalid_envelope'}); return; }
      considerCampaign(envelope, received);
      const old=state.latest;
      if (old && old.api.instance_id === envelope.api.instance_id && envelope.api.sequence <= old.api.sequence) return;
      state.latest=envelope;
      const anchor=envelope.ghost && envelope.ghost.current_twap;
      if (anchor && (state.latestAnchor === null || anchor.source_timestamp_ms > state.latestAnchor))
        state.latestAnchor=anchor.source_timestamp_ms;
    });
    async function snapshot() {
      if (state.getBusy || state.done) return;
      state.getBusy=true;
      const startMs=performance.now(), controller=new AbortController();
      let headersMs=null, responseStatus=null, abortFiredMs=null;
      state.pending.add(controller);
      const abort=setTimeout(() => { abortFiredMs=performance.now(); controller.abort(); },3000);
      try {
        const response=await fetch('/forecasts/chainlink-twap/live',{cache:'no-store',signal:controller.signal});
        headersMs=performance.now(); responseStatus=response.status;
        const text=await response.text(), endMs=performance.now();
        if (state.done) return;
        const server=response.headers.get('x-ghost-api-time-ns');
        if (!record('snapshot',{start_ms:startMs,headers_ms:headersMs,end_ms:endMs,
            status:response.status,server_time_ns:server,data:text,
            abort_timer_fired_ms:abortFiredMs,configured_timeout_ms:3000},endMs)) return;
        if (response.status === 200 && server !== null) {
          const low=BigInt(server)-ns(endMs), high=BigInt(server)-ns(startMs);
          if (state.offsetLower === null) { state.offsetLower=low; state.offsetUpper=high; }
          else {
            const newLow=state.offsetLower > low ? state.offsetLower : low;
            const newHigh=state.offsetUpper < high ? state.offsetUpper : high;
            if (newLow > newHigh) {
              state.offsetLower=null; state.offsetUpper=null; state.badCalibration=true;
              record('error',{reason:'incompatible_clock_brackets'});
            } else { state.offsetLower=newLow; state.offsetUpper=newHigh; }
          }
        }
      } catch (error) {
        if (!state.done) record('error',{reason:'snapshot_error',message:String(error),
          start_ms:startMs,end_ms:performance.now(),headers_ms:headersMs,response_status:responseStatus,
          abort_timer_fired_ms:abortFiredMs,configured_timeout_ms:3000,
          stage:headersMs === null ? 'before_headers' : 'reading_body'});
      } finally { clearTimeout(abort); state.pending.delete(controller); state.getBusy=false; }
    }
    void snapshot();
    snapshotTimer=setInterval(snapshot,5000);
    function scheduleSample() {
      if (state.done) return;
      const nextIndex=Math.max(state.lastRecordedIndex+1,Math.floor((performance.now()-start)/100)+1);
      probeTimer=setTimeout(sample,Math.max(1,start+nextIndex*100-performance.now()));
    }
    function sample() {
      if (state.done) return;
      const now=performance.now();
      if (now-start >= observation+drain) { finish('completed'); return; }
      const plannedIndex=Math.floor((now-start)/100);
      // Browsers may invoke a timeout fractionally before its requested due
      // time. Wait again instead of recording the same grid bin twice.
      if (plannedIndex <= state.lastRecordedIndex) { scheduleSample(); return; }
      const envelope=state.latest, p=envelope && envelope.ghost;
      const calibrated=state.offsetUpper !== null && !state.badCalibration;
      let usable=[], deadline=null, classificationError=null;
      try {
        if (calibrated && p) {
          const expiry=BigInt(p.valid_until_wall_ns);
          const sendExpiry=BigInt(envelope.api.send_wall_ns)+BigInt(envelope.api.remaining_ns);
          deadline=(expiry < sendExpiry ? expiry : sendExpiry)-state.offsetUpper;
          if (ns(now) < deadline) {
            const eligible=p.publication_eligibility.eligible_horizons;
            usable=p.forecasts.filter(f => eligible.includes(f.horizon_s) && f.price !== null &&
              ['healthy','degraded'].includes(f.quality) &&
              (state.latestAnchor === null || f.target_source_timestamp_ms > state.latestAnchor)).map(f=>f.horizon_s);
          }
        }
      } catch (error) { usable=[]; classificationError=String(error); }
      const saved=record('probe',{planned_index:plannedIndex,
        phase:now-start < observation ? 'observation' : 'follow_through',
        calibrated:calibrated && classificationError === null, usable_horizons:usable,
        classification_error:classificationError, state:envelope ? envelope.api.state : 'awaiting_connection',
        selected_run_id:p ? p.run_id : null, selected_decision_id:p ? p.decision_id : null,
        api_instance_id:envelope ? envelope.api.instance_id : null,
        api_generation:envelope ? envelope.api.generation : null, api_sequence:envelope ? envelope.api.sequence : null,
        latest_anchor_source_ms:state.latestAnchor,
        offset_lower_ns:state.offsetLower === null ? null : String(state.offsetLower),
        offset_upper_ns:state.offsetUpper === null ? null : String(state.offsetUpper),
        effective_deadline_browser_ns:deadline === null ? null : String(deadline)},now);
      // Align the next tick to the original monotonic grid, skipping elapsed
      // slots. Do not backdate or manufacture samples after a stalled browser.
      if (saved) state.lastRecordedIndex=plannedIndex;
      scheduleSample();
    }
    sample();
    finishTimer=setTimeout(() => finish('completed'),observation+drain+100);
    return {started:true,observation_ms:observation,drain_ms:drain,start_browser_ms:start,
      origin:location.origin,max_records:maxRecords,max_bytes:maxBytes,
      campaign_attachment:'window.ghostProbe.setCampaign(start_ms, optional_run_id)'};
  });
}
