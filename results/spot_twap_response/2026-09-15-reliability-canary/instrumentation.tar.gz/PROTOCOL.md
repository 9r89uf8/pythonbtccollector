# One-hour reliability canary: browser observation

The producer's campaign is exactly `[S, S + 3,600,000 ms)`. Its existing fixed
one-hour limit is never extended for browser follow-through. The operator stops
the collector at that end with recent audit rows still present, exercising the
new shutdown drain. Shutdown completion is checked from logs, terminal database
rows and outbox state; browser observations cannot establish audit completion.

Start this browser probe immediately before activation, on the existing
loopback API through the owner's SSH tunnel. It records 3,600,000 ms of forecast
admissions and 120,000 ms more of local observation. Continuing the browser does
not continue the producer. After producer stop, official anchors may cease to
appear in ghost envelopes; unmatched exact targets remain censored. Do not
substitute collector target clocks or periodic GET values for browser SSE pairs.

Attach the operator's exact server campaign start using
`window.ghostProbe.setCampaign(start_ms, optional_run_id)`. The helper records
the browser time at which metadata was supplied; that is not the activation time.
It preserves prior samples and exports metadata separately in `campaign.json`.
A missing run ID can later be confirmed for the same start; the campaign cannot
be replaced. First-matching-object metadata remains provisional until exact
producer bytes/run identity are joined to the audit. The complete raw SSE strings
are retained for independent re-pairing and qualification.

Report these panels separately:

- **Full browser admission interval:** `[capture start, +3,600,000 ms)` has
  36,000 planned 100 ms observation bins, including startup and unknown/missing
  samples. The additional 1,200 follow-through bins are separate. Browser timers
  skip elapsed bins and never manufacture catch-up observations. A saved-index
  guard rejects early duplicate callbacks; completion rechecks the actual
  monotonic deadline rather than trusting that its timer fired on time.
- **Campaign overlap:** derive overlap from operator server clocks and saved
  GET clock brackets; do not assume browser and server wall clocks agree or
  that capture started at S. Separate uncertain boundary/uncalibrated bins.
- **After first same-campaign object plus 65 s:** derive the exact browser
  cutoff from the verified matching object and use the resulting bin count.
  This is a declared observation-age exclusion, not proof that history is
  complete or inputs are healthy. Do not reuse the old capture+65 s denominator.
- **Comparable accuracy before shutdown:** select the slice ending at least
  120 s before the actual operator stop using joined campaign timing and a
  conservative browser-to-server clock bracket. Do not handwave the browser
  start offset. Report all-hour admissions/censoring as well as this slice;
  audit acknowledgement is neither a browser receipt nor an exact target pair.

Lead uses first qualifying SSE forecast handler time to the later exact source
stamp/value anchor handler time in this same stream. Prices stay E18 strings;
offline errors use Decimal. Positive matched lead is conditional on excluding
targets already observed at the forecast receipt. Skipped anchors stay censored.
Rendering, absolute one-way network latency and an economic edge are not measured.

Expiry telemetry retains the prior conservative GET-derived clock bracket and
the smaller of producer expiry and API send time plus API remaining lifetime.
It never starts a fresh lifetime at browser receipt. A bracket conflict latches
uncalibrated state; lost calibration must not become a usable prediction. These
classifications remain browser diagnostics until independently reconstructed.
The protocol does not alter forecast math or make GET and SSE interchangeable.

GET runs at most once every five seconds, with one request in flight and a
three-second abort timer. Records include request start, headers receipt, body
completion/error and the actual abort-timer firing time. This identifies the
probe's own abort action without claiming why the request was delayed. There is
no additional load episode or unread secondary stream in this canary.

The capture stops at 100,000 records or 128 MiB serialized JSONL bytes, reserving
space for an end marker. Limits are not raised automatically. Capped/interrupted
captures can be exported but are explicitly incomplete. No callbacks append
after finalization. Data is buffered in browser memory until export; samples are
not individually durable. Keep the page alive and use the status script to check
progress; do not replace the page or start a second probe over existing evidence.

The existing local Redis observer already accepts `(ghost-canary-v6, contract 4)`
and can independently sample `[S,S+1h)` on its 36,000-bin fixed grid. It measures
cache presence/freshness, not browser delivery or whether an official target
has already arrived. Keep Redis coverage and browser coverage in separate tables.

The existing Checkpoint C analyzer accepts these JSONL kinds and declared
3,600,000/120,000 ms durations. Its default post-warmup panel is still
capture+65 s; the operator must supply a derived `--warmup-ms` or label that panel
as capture-relative. Campaign overlap and the comparable accuracy slice require
the separately declared offline join. Incomplete captures must not be passed off
as complete merely because an `end` record exists.

`browser_probe.js`, `browser_status.js` and `browser_export.js` are local
Playwright run-code functions. They have not been executed against a browser by
the preparing agent. Run `export_preflight.ps1` immediately before export: the
local shell check refuses existing browser.jsonl or campaign.json. The export
function uses two browser downloads and refuses a second attempt from the same
page. Preserve partial files if one download fails; do not blindly retry over them.
