async (page) => {
  const output='C:/Users/alexa/PycharmProjects/polycollector/dist/ghost-checkpoint-a-release/output/playwright/reliability-canary';
  const destination=output+'/browser.jsonl';
  const metadataPath=output+'/campaign.json';
  // Run export_preflight.ps1 immediately before this function. Playwright's
  // run-code context has no require/fs access, so filesystem checks live there.
  const status=await page.evaluate(() => {
    const p=window.ghostProbe;
    return p && {done:p.done,exporting:p.exporting === true,records:p.records.length,bytes:p.bytes,
      end:p.records[p.records.length-1],campaign_metadata:p.campaignMetadata,
      campaign:p.campaign,first_campaign_object:p.firstCampaignObject};
  });
  if (!status || !status.done || status.end.kind !== 'end') throw Error('capture not finalized');
  if (status.exporting) throw Error('capture export already attempted; preserve any partial files');
  // Interrupted/capped captures are exportable evidence, but their explicit
  // incomplete end marker must never be relabeled as a completed hour.
  await page.evaluate(() => { window.ghostProbe.exporting=true; });
  for (const [kind,name,path] of [['capture','ghost-reliability-browser.jsonl',destination],
                                 ['metadata','ghost-reliability-campaign.json',metadataPath]]) {
    const downloadPromise=page.waitForEvent('download');
    await page.evaluate(({kind,name}) => {
      const p=window.ghostProbe;
      const metadata={done:p.done,records:p.records.length,bytes:p.bytes,end:p.records[p.records.length-1],
        campaign_metadata:p.campaignMetadata,campaign:p.campaign,first_campaign_object:p.firstCampaignObject};
      const text=kind === 'capture' ? p.records.map(r => JSON.stringify(r)).join('\n')+'\n'
        : JSON.stringify(metadata,null,2)+'\n';
      const url=URL.createObjectURL(new Blob([text],{type:'application/octet-stream'}));
      const link=document.createElement('a'); link.href=url; link.download=name; link.click();
      setTimeout(() => URL.revokeObjectURL(url),10000);
    },{kind,name});
    const download=await downloadPromise;
    await download.saveAs(path);
  }
  return {saved:true,records:status.records,bytes:status.bytes,complete:status.end.complete,destination,metadataPath};
}
