async (page) => await page.evaluate(() => {
  const p=window.ghostProbe;
  if (!p) return {missing:true};
  const counts={};
  for (const row of p.records) counts[row.kind]=(counts[row.kind]||0)+1;
  return {done:p.done,elapsed_ms:performance.now()-p.start_ms,records:p.records.length,
    bytes:p.bytes,counts,campaign:p.campaign,first_campaign_object:p.firstCampaignObject,
    latest:p.latest ? {api:p.latest.api,run_id:p.latest.ghost?.run_id,
      decision_id:p.latest.ghost?.decision_id} : null,
    calibrated:p.offsetUpper !== null && !p.badCalibration,
    last_probe:p.records.filter(r => r.kind === 'probe').slice(-1)[0],
    errors:p.records.filter(r => r.kind === 'error').slice(-5)};
})
