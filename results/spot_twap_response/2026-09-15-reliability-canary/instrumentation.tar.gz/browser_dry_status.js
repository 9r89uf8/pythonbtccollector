async (page) => await page.evaluate(() => {
  const p=window.ghostProbeDry2;
  const bins=p.records.filter(r=>r.kind==='probe').map(r=>r.planned_index);
  return {done:p.done,end:p.records.at(-1),probes:bins.length,
    unique_bins:new Set(bins).size,first_bin:bins[0],last_bin:bins.at(-1),
    duplicate_bins:bins.length-new Set(bins).size,user_agent:navigator.userAgent,
    visibility:document.visibilityState,origin:location.origin};
})
