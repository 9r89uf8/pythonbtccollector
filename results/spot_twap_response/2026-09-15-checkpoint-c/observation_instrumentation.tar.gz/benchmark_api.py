import hashlib
import http.client
import json
from pathlib import Path
import sys
import time

output=Path(sys.argv[1])
if output.exists(): raise SystemExit('refusing overwrite')
connection=http.client.HTTPConnection('127.0.0.1',9000,timeout=1)
records=[]
started=time.time_ns()
try:
    for _ in range(30):
        begin=time.monotonic_ns()
        connection.request('GET','/forecasts/chainlink-twap/live',headers={'Accept-Encoding':'gzip'})
        response=connection.getresponse()
        body=response.read()
        end=time.monotonic_ns()
        records.append({'status':response.status,'duration_ns':end-begin,
                        'payload_bytes':len(body),'payload_sha256':hashlib.sha256(body).hexdigest(),
                        'content_encoding':response.getheader('Content-Encoding'),
                        'cache_control':response.getheader('Cache-Control')})
        time.sleep(.2)
finally:
    connection.close()
output.write_text(json.dumps({'start_wall_ns':str(started),'end_wall_ns':str(time.time_ns()),
    'path':'loopback; one reused HTTP connection; 30 requests, 200ms spacing',
    'records':records},indent=2)+'\n')
