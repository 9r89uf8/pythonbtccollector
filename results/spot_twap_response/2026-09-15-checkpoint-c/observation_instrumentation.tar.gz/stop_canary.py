"""Bounded operator stop for the named C observation; no campaign reset."""
import json
import fcntl
from pathlib import Path
import subprocess
import sys
import time

expected_state, output = sys.argv[1:]
lock = open(output + '.lock', 'a')
fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
env = Path('/etc/price-collector/collector.env')
lines = env.read_text().splitlines()
values = dict(line.split('=', 1) for line in lines if line and not line.startswith('#') and '=' in line)
if values.get('GHOST_TWAP_STATE_DIRECTORY') != expected_state:
    raise SystemExit('Refusing to stop a different campaign')
if Path(output).exists():
    previous = json.loads(Path(output).read_text())
    assert previous['state_directory'] == expected_state
    assert values.get('GHOST_TWAP_ENABLED') == 'false', 'completed campaign was re-enabled'
    print('Matching campaign already stopped; original evidence preserved')
    raise SystemExit(0)
changed = []
for line in lines:
    changed.append('GHOST_TWAP_ENABLED=false' if line.startswith('GHOST_TWAP_ENABLED=') else line)
env.write_text('\n'.join(changed) + '\n')
subprocess.run(['systemctl', 'restart', 'price-collector-polymarket-chainlink'], check=True)
result = {'operator_stop_wall_ns':str(time.time_ns()), 'state_directory':expected_state,
          'reason':'checkpoint_c_observation_complete', 'flag_enabled':False}
with open(output, 'x') as handle:
    handle.write(json.dumps(result, indent=2) + '\n')
