"""Capture bounded, nonsecret production checks after the C observation."""
import json
from pathlib import Path
import subprocess
import sys

remote = r'''
import hashlib,json,pathlib,subprocess,time,urllib.request,urllib.error
def command(args):
    p=subprocess.run(args,capture_output=True,text=True,timeout=30)
    return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
base=pathlib.Path('/opt/price-collector')
state=pathlib.Path('/var/lib/price-collector/ghost-c-api-20260915T021552Z')
result={'captured_wall_ns':str(time.time_ns()),'git':command(['sudo','-u','pricecollector','git','-C',str(base),'rev-parse','HEAD']),
 'git_status':command(['sudo','-u','pricecollector','git','-C',str(base),'status','--porcelain']),
 'services':command(['systemctl','is-active','price-api','price-collector-polymarket-chainlink','price-collector','price-collector-binance-futures','price-collector-polymarket-probabilities','redis-server']),
 'audit':command(['sudo','-u','postgres',str(base/'.venv/bin/python'),'-m','price_collector.ghost_twap_admin','status']),
 'ghost_key_exists':command(['redis-cli','EXISTS','btc:live:ghost_chainlink_twap_60s']),
 'listeners':command(['ss','-ltn']),
 'outbox_rows':len(list(state.glob('*.row'))),
 'source_sha256':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in ['price_collector/api.py','price_collector/ghost_twap_api.py','price_collector/ghost_twap_payload.py','price_collector/ghost_twap_stream.py']}}
result['safe_settings']={}
for name,allowed in [('api.env',{'GHOST_TWAP_API_ENABLED'}),('collector.env',{'GHOST_TWAP_ENABLED','GHOST_TWAP_CANARY_START_MS','GHOST_TWAP_STATE_DIRECTORY','GHOST_TWAP_SOURCE_MAX_AGE_MS','GHOST_TWAP_RECEIPT_MAX_AGE_MS'})]:
    result['safe_settings'][name]=[l for l in (pathlib.Path('/etc/price-collector')/name).read_text().splitlines() if l.split('=',1)[0] in allowed]
result['http']={}
for path in ['/healthz','/markets/current/live','/forecasts/chainlink-twap/live']:
    try:
        with urllib.request.urlopen('http://127.0.0.1:9000'+path,timeout=5) as response:
            result['http'][path]={'status':response.status,'body':response.read().decode()}
    except urllib.error.HTTPError as exc:
        result['http'][path]={'status':exc.code,'body':exc.read().decode()}
result['campaign_hashes']={}
for p in [pathlib.Path('/var/lib/price-collector/ghost-twap/campaign.json'),pathlib.Path('/var/lib/price-collector/ghost-twap-combined-20260914T223348Z/campaign.json'),state/'campaign.json']:
    result['campaign_hashes'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
result['shutdown_journal']=command(['journalctl','-u','price-collector-polymarket-chainlink','--since','2026-09-15 02:32:50 UTC','--until','2026-09-15 02:33:05 UTC','-n','120','--no-pager','-o','json'])
print(json.dumps(result,indent=2))
'''
output=Path(sys.argv[1])
assert not output.exists()
process=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=20','root@152.42.247.86',
                        'cd /opt/price-collector && python3 -'],input=remote.encode(),capture_output=True,timeout=180)
if process.returncode:
    raise SystemExit(process.stderr.decode())
json.loads(process.stdout)
output.write_bytes(process.stdout)
print(output)
