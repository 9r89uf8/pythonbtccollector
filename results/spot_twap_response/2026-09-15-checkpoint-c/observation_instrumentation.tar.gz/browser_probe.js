async (page) => {
  return await page.evaluate(() => {
    if (window.ghostProbe && !window.ghostProbe.done) throw Error('probe already running');
    const start = performance.now();
    const observation = 900000, drain = 120000;
    const state = {records: [], done: false, latest: null, offsetLower: null, offsetUpper: null,
      latestAnchor: null, badCalibration: false, getBusy: false, pending: new Set()};
    window.ghostProbe = state;
    const ns = t => BigInt(Math.round(t * 1000000));
    const record = (kind, fields={}) => {
      if (state.done && kind !== 'end') return;
      state.records.push({kind, browser_ms: performance.now(), ...fields});
    };
    record('start', {observation_ms: observation, drain_ms: drain, wall_ms: Date.now()});
    const source = new EventSource('/forecasts/chainlink-twap/stream');
    source.addEventListener('open', () => record('open'));
    source.addEventListener('error', () => record('error', {reason:'eventsource_error', ready_state:source.readyState}));
    source.addEventListener('ghost', event => {
      if (state.done || performance.now()-start >= observation+drain) return;
      const received = performance.now();
      state.records.push({kind:'ghost', browser_ms:received, data:event.data});
      const envelope = JSON.parse(event.data);
      const old = state.latest;
      if (old && old.api.instance_id === envelope.api.instance_id &&
          envelope.api.sequence <= old.api.sequence) return;
      state.latest = envelope;
      const anchor = envelope.ghost && envelope.ghost.current_twap;
      if (anchor && (state.latestAnchor === null || anchor.source_timestamp_ms > state.latestAnchor))
        state.latestAnchor = anchor.source_timestamp_ms;
    });
    async function snapshot() {
      if (state.getBusy || state.done) return;
      state.getBusy = true;
      const startMs = performance.now();
      const controller = new AbortController();
      state.pending.add(controller);
      const abort = setTimeout(() => controller.abort(), 3000);
      try {
        const response = await fetch('/forecasts/chainlink-twap/live', {cache:'no-store', signal:controller.signal});
        const text = await response.text();
        if (state.done) return;
        const endMs = performance.now();
        const server = response.headers.get('x-ghost-api-time-ns');
        state.records.push({kind:'snapshot', browser_ms:endMs, start_ms:startMs, end_ms:endMs,
          status:response.status, server_time_ns:server, data:text});
        if (response.status === 200 && server !== null) {
          const low = BigInt(server)-ns(endMs), high=BigInt(server)-ns(startMs);
          if (state.offsetLower === null) { state.offsetLower=low; state.offsetUpper=high; }
          else {
            const newLow=state.offsetLower > low ? state.offsetLower : low;
            const newHigh=state.offsetUpper < high ? state.offsetUpper : high;
            if (newLow > newHigh) {
              state.offsetLower=null; state.offsetUpper=null; state.badCalibration=true;
              record('error', {reason:'incompatible_clock_brackets'});
            } else { state.offsetLower=newLow; state.offsetUpper=newHigh; }
          }
        }
      } catch (error) { if (!state.done) record('error',{reason:'snapshot_error',message:String(error)}); }
      finally { clearTimeout(abort); state.pending.delete(controller); state.getBusy=false; }
    }
    void snapshot();
    const snapshotTimer = setInterval(snapshot, 5000);
    const probeTimer = setInterval(() => {
      const now=performance.now();
      if (now-start >= observation) return;
      const envelope=state.latest, p=envelope && envelope.ghost;
      const calibrated=state.offsetUpper !== null && !state.badCalibration;
      let usable=[], deadline=null;
      if (calibrated && p) {
        const expiry=BigInt(p.valid_until_wall_ns);
        const sendExpiry=BigInt(envelope.api.send_wall_ns)+BigInt(envelope.api.remaining_ns);
        deadline=(expiry < sendExpiry ? expiry : sendExpiry)-state.offsetUpper;
        if (ns(now) < deadline) {
          const eligible=p.publication_eligibility.eligible_horizons;
          usable=p.forecasts.filter(f => eligible.includes(f.horizon_s) && f.price !== null &&
            ['healthy','degraded'].includes(f.quality) &&
            (state.latestAnchor === null || f.target_source_timestamp_ms > state.latestAnchor)).map(f=>f.horizon_s);
        }
      }
      state.records.push({kind:'probe', browser_ms:now, calibrated, usable_horizons:usable,
        state:envelope ? envelope.api.state : 'awaiting_connection',
        selected_run_id:p ? p.run_id : null, selected_decision_id:p ? p.decision_id : null,
        api_instance_id:envelope ? envelope.api.instance_id : null,
        api_generation:envelope ? envelope.api.generation : null,
        api_sequence:envelope ? envelope.api.sequence : null,
        latest_anchor_source_ms:state.latestAnchor,
        offset_lower_ns:state.offsetLower === null ? null : String(state.offsetLower),
        offset_upper_ns:state.offsetUpper === null ? null : String(state.offsetUpper),
        effective_deadline_browser_ns:deadline === null ? null : String(deadline)});
    },100);
    // A bounded additional consumer and GET load, separate from the measured stream.
    const loadTimer=setTimeout(async () => {
      record('load_start',{description:'30 seconds; one unread fetch stream and up to 5 concurrent GETs per second'});
      const slow=new AbortController(); state.pending.add(slow);
      fetch('/forecasts/chainlink-twap/stream',{signal:slow.signal}).catch(()=>{});
      let active=0;
      const timer=setInterval(async()=>{
        if (active>=5 || state.done) return;
        active++;
        const c=new AbortController(); state.pending.add(c);
        const stop=setTimeout(()=>c.abort(),3000);
        try { await (await fetch('/forecasts/chainlink-twap/live',{cache:'no-store',signal:c.signal})).arrayBuffer(); }
        catch (_) {} finally {clearTimeout(stop);state.pending.delete(c);active--;}
      },200);
      setTimeout(()=>{clearInterval(timer);slow.abort();state.pending.delete(slow);record('load_end');},30000);
    },300000);
    setTimeout(()=>{
      state.done=true; source.close(); clearInterval(snapshotTimer); clearInterval(probeTimer);clearTimeout(loadTimer);
      for (const controller of state.pending) controller.abort();
      record('end',{wall_ms:Date.now()});
    },observation+drain+100);
    return {started:true,observation_ms:observation,drain_ms:drain,origin:location.origin};
  });
}
