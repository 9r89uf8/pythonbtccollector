"""One fresh, bounded C observation; existing stopped campaigns stay untouched."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import pwd
import shutil
import subprocess
import time

root = Path('/opt/price-collector')
env = Path('/etc/price-collector/collector.env')
lines = env.read_text().splitlines()
values = dict(line.split('=',1) for line in lines if line and not line.startswith('#') and '=' in line)
assert values.get('GHOST_TWAP_ENABLED') == 'false'
assert values.get('GHOST_TWAP_SOURCE_MAX_AGE_MS') == '5000'
assert values.get('GHOST_TWAP_RECEIPT_MAX_AGE_MS') == '3000'
assert shutil.disk_usage('/var/lib/postgresql').free > 10*1024**3
old = Path(values['GHOST_TWAP_STATE_DIRECTORY'])
assert not list(old.rglob('*.row')), 'previous outbox is not drained'
status = subprocess.check_output(['sudo','-u','postgres',str(root/'.venv/bin/python'),
    '-m','price_collector.ghost_twap_admin','status'], cwd=root, text=True)
print(status, flush=True)
checked = json.loads(status)
assert checked['incomplete_count'] == 0
assert checked['measurement']['relation_bytes'] < 1536*1024**2
assert checked['measurement']['tablespaces'] == ['pg_default']
suffix=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
state=Path('/var/lib/price-collector/ghost-c-api-'+suffix)
evidence=Path('/var/lib/price-collector/ghost-c-observation-'+suffix)
assert not state.exists() and not evidence.exists()
state.mkdir(mode=0o700)
evidence.mkdir(mode=0o700)
identity=pwd.getpwnam('pricecollector')
os.chown(state,identity.pw_uid,identity.pw_gid)
os.chown(evidence,identity.pw_uid,identity.pw_gid)
start=int(time.time_ns()//1_000_000)
unit='ghost-c-stop-'+suffix.lower()
replacements={'GHOST_TWAP_STATE_DIRECTORY':str(state),'GHOST_TWAP_CANARY_START_MS':str(start),
              'GHOST_TWAP_ENABLED':'true'}
assert all(sum(line.startswith(k+'=') for line in lines)==1 for k in replacements)
updated=[line.split('=',1)[0]+'='+replacements[line.split('=',1)[0]]
         if line.split('=',1)[0] in replacements else line for line in lines]
metadata={'campaign_start_ms':start,'producer_max_observation_ms':1_020_000,
          'browser_admission_ms':900_000,'browser_anchor_followthrough_ms':120_000,
          'state_directory':str(state),'evidence_directory':str(evidence),'stop_unit':unit,
          'previous_state_directory':str(old),
          'previous_state_sha256':hashlib.sha256((old/'campaign.json').read_bytes()).hexdigest(),
          'commit':subprocess.check_output(['sudo','-u','pricecollector','git','rev-parse','HEAD'],cwd=root,text=True).strip()}
(evidence/'start.json').write_text(json.dumps(metadata,indent=2)+'\n')
subprocess.run(['systemd-run','--unit='+unit,'--on-active=17min','--timer-property=AccuracySec=1s',
                '--collect','/usr/bin/python3','/var/lib/price-collector/ghost-c-stop.py',
                str(state),str(evidence/'stop.json')],check=True)
env.write_text('\n'.join(updated)+'\n')
try:
    subprocess.run(['systemctl','restart','price-collector-polymarket-chainlink'],check=True)
except BaseException:
    subprocess.run(['/usr/bin/python3','/var/lib/price-collector/ghost-c-stop.py',str(state),str(evidence/'stop.json')])
    raise
print(json.dumps(metadata),flush=True)
