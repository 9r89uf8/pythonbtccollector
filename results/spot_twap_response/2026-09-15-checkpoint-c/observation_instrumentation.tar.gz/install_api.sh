#!/bin/bash
set -euo pipefail
cd /opt/price-collector
python3 - <<'PY'
from pathlib import Path
values = dict(line.split('=', 1) for line in Path('/etc/price-collector/collector.env').read_text().splitlines()
              if line and not line.startswith('#') and '=' in line)
assert values.get('GHOST_TWAP_ENABLED', 'false').lower() == 'false', 'producer must be disabled'
PY
sudo -u pricecollector git pull --ff-only
sudo -u pricecollector .venv/bin/pip install -r requirements.txt
python3 - <<'PY'
from pathlib import Path
p = Path('/etc/price-collector/api.env')
lines = p.read_text().splitlines()
matches = [i for i,line in enumerate(lines) if line.startswith('GHOST_TWAP_API_ENABLED=')]
assert len(matches) <= 1
if matches: lines[matches[0]] = 'GHOST_TWAP_API_ENABLED=true'
else: lines.append('GHOST_TWAP_API_ENABLED=true')
# Updating this existing inode preserves owner and permissions.
p.write_text('\n'.join(lines) + '\n')
PY
sudo systemctl restart price-api
sudo systemctl status price-api --no-pager
sleep 2
curl --fail --max-time 5 http://127.0.0.1:9000/healthz
curl --fail --max-time 5 http://127.0.0.1:9000/markets/current/live
curl -sS -i --max-time 5 http://127.0.0.1:9000/forecasts/chainlink-twap/live
curl -sS -N --max-time 3 http://127.0.0.1:9000/forecasts/chainlink-twap/stream || test "$?" = 28
sudo journalctl -u price-api -n 30 --no-pager
sudo -u pricecollector git rev-parse HEAD
redis-cli EXISTS btc:live:ghost_chainlink_twap_60s
