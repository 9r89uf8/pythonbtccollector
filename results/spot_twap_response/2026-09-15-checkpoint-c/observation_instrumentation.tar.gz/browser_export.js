async (page) => {
  const status=await page.evaluate(()=>({done:window.ghostProbe?.done,records:window.ghostProbe?.records.length}));
  if (!status.done) throw Error('Refusing to export an incomplete capture');
  const downloadPromise=page.waitForEvent('download');
  await page.evaluate(()=>{
    const text=window.ghostProbe.records.map(r=>JSON.stringify(r)).join('\n')+'\n';
    const blob=new Blob([text],{type:'application/x-ndjson'});
    const url=URL.createObjectURL(blob), link=document.createElement('a');
    link.href=url; link.download='ghost-browser.jsonl'; link.click();
    setTimeout(()=>URL.revokeObjectURL(url),10000);
  });
  const download=await downloadPromise;
  await download.saveAs('C:/Users/alexa/PycharmProjects/polycollector/dist/ghost-checkpoint-a-release/dist/checkpoint-c/browser.jsonl');
  return {saved:true,records:status.records};
}
