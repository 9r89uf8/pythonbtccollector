"""Recovery-only operator run: no worker start, no feeds, no Redis, no new forecast."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile
import time

import asyncpg
from price_collector.ghost_twap_runtime import GhostRuntime, GhostSettings
from price_collector.ghost_twap_spool import GhostSpool
from price_collector.ghost_twap_store import GhostAuditStore

STATE=Path('/var/lib/price-collector/ghost-c-api-20260915T021552Z')
EVIDENCE=Path('/var/lib/price-collector/ghost-c-observation-20260915T021552Z')
RUN='d31ac97c83fb4635bc64fef79fedafa9'
START=1789438552981

class NoRedis:
    def __getattr__(self, name):
        raise AssertionError('recovery must never access Redis: '+name)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

async def main():
    apply=sys.argv[-1]=='--apply'
    settings=GhostSettings()
    assert not settings.enabled and settings.state_directory==STATE and settings.canary_start_ms==START
    campaign=(STATE/'campaign.json').read_bytes()
    assert json.loads(campaign)['start_ms']==START
    assert (EVIDENCE/'stop.json').is_file()
    assert not list(STATE.glob('*.tmp')), 'archive interrupted temporary evidence before opening spool'
    spool=GhostSpool(STATE,settings.audit_max_records,settings.record_max_bytes)
    spool.open()  # The same exclusive lock used by the live worker.
    pool=None
    try:
        saved=spool.read_all()
        assert len(saved)<=512 and all(r['run_id']==RUN for r in saved)
        pool=await asyncpg.create_pool(dsn=os.environ['DATABASE_URL'],min_size=1,max_size=1,
                                      timeout=5,command_timeout=5)
        store=GhostAuditStore(pool)
        rows=await store.list_incomplete(limit=100)
        assert len(rows)<100 and all(r['run_id']==RUN for r in rows)
        originals={}
        for record in [*saved,*[dict(r) for r in rows]]:
            key=(record['run_id'],record['decision_id'])
            stored=await store.get_record(*key)
            if stored is not None:
                assert stored['frozen_json']==record['frozen_json']
                if stored['version']==record['version']:
                    assert stored['state_json']==record['state_json'] and stored['terminal']==record['terminal']
                if stored['version']>record['version']: record=dict(stored)
            if key not in originals or record['version']>originals[key]['version']:
                originals[key]=record
        assert len(originals)<=512
        files=sorted(STATE.glob('*.row'))
        plan={'run_id':RUN,'state_directory':str(STATE),'start_ms':START,
              'campaign_sha256':digest(campaign),'spool_rows':len(saved),'incomplete_rows':len(rows),
              'outbox_sha256':{p.name:digest(p.read_bytes()) for p in files},
              'records':[{'decision_id':key[1],'version':r['version'],
                          'frozen_sha256':digest(r['frozen_json'].encode()),
                          'state_sha256':digest(r['state_json'].encode())}
                         for key,r in sorted(originals.items())]}
        if not apply:
            with (EVIDENCE/'recovery_plan.json').open('x') as handle:
                json.dump(plan,handle,indent=2)
            print(json.dumps({k:v for k,v in plan.items() if k not in ('records','outbox_sha256')}))
            return
        assert plan==json.loads((EVIDENCE/'recovery_plan.json').read_text()), 'evidence changed after dry run'
        with tarfile.open(EVIDENCE/'outbox_before_recovery.tar.gz','x:gz') as archive:
            for path in [STATE/'campaign.json',*files]:
                archive.add(path,arcname=path.name,recursive=False)
        with (EVIDENCE/'outbox_before_recovery.tar.gz').open('rb') as handle:
            os.fsync(handle.fileno())
        directory_fd=os.open(EVIDENCE,os.O_RDONLY|os.O_DIRECTORY)
        try: os.fsync(directory_fd)
        finally: os.close(directory_fd)
        runtime=GhostRuntime(settings,store,NoRedis(),spool)
        # Do not call start/close: only the tested, publication-free recovery path.
        for record in saved:
            await runtime._recover(record)
            spool.remove(record)
        for row in await store.list_incomplete(limit=100):
            assert row['run_id']==RUN
            await runtime._recover(dict(row))
        assert not await store.list_incomplete(limit=1)
        assert not spool.read_all()
        for key,before in originals.items():
            after=await store.get_record(*key)
            assert after['terminal'] and after['frozen_json']==before['frozen_json']
            prior=json.loads(before['state_json']); current=json.loads(after['state_json'])
            for horizon,target in prior['targets'].items():
                if target['status']!='pending':
                    assert current['targets'][horizon]==target, 'observed target changed'
            if prior['publication']['status']=='acknowledged':
                assert current['publication']==prior['publication'], 'publication evidence changed'
        assert (STATE/'campaign.json').read_bytes()==campaign
        result={'run_id':RUN,'reconciled_records':len(originals),'outbox_rows_after':0,
                'incomplete_rows_after':0,'frozen_and_observed_targets_unchanged':True,
                'campaign_sha256':digest(campaign),'completed_wall_ns':str(time.time_ns()),
                'archive_sha256':digest((EVIDENCE/'outbox_before_recovery.tar.gz').read_bytes())}
        with (EVIDENCE/'recovery_complete.json').open('x') as handle:
            json.dump(result,handle,indent=2)
        print(json.dumps(result))
    finally:
        if pool is not None: await pool.close()
        spool.close()

asyncio.run(main())
