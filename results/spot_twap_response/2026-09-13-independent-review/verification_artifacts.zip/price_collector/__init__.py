"""BTCUSDT price collector package."""

