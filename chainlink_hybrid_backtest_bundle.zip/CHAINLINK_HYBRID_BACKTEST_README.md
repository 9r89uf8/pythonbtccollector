# Chainlink BTC hybrid backtest

This test is designed for a local directory containing many files with names such as:

```text
btc_5m_market_5948878_shadow_evaluations_catchup_ratio_l3000_b100.json
```

It compares the existing projected Chainlink price with several causal futures-basis models without using future outcomes to construct the signals.

## 1. Install

Python 3.10 or newer is recommended.

```bash
python -m pip install numpy pandas
```

The test requires only `numpy` and `pandas`.

## 2. Recommended command for 200 markets

On Windows PowerShell:

```powershell
python .\chainlink_hybrid_backtest.py `
  --input-dir "C:\Users\alexa\PycharmProjects\polycollector\your_market_json_directory" `
  --pattern "btc_5m_market_*_shadow_evaluations_catchup_ratio_l3000_b100.json" `
  --output-dir ".\chainlink_hybrid_results" `
  --test-markets 40 `
  --min-train-markets 40 `
  --validation-block-markets 10 `
  --validation-step-markets 10
```

On cmd.exe or Bash, put the command on one line or use the shell's normal line-continuation character.

The default selection rule is `one_se`, which selects the simplest model statistically close to the validation winner. For research, run a second comparison with:

```text
--selection-rule best
```

Do not mix the two runs when judging the final holdout. Treat the default `one_se` result as the conservative production candidate and the `best` result as a challenger.

## 3. Chronological test design

With 200 markets and `--test-markets 40`:

- The first 160 markets are the development period.
- The last 40 markets are untouched until final evaluation.
- Within the first 160 markets, the script performs expanding-window validation. For example, it trains on the first 40 markets and validates on the next 10, then trains on the first 50 and validates on the next 10, and so on.
- Hyperparameters and coefficients are fitted using one forecast per three-second horizon, not every overlapping 500 ms forecast.
- Final results are reported both on every valid row and on the non-overlapping sample.
- Confidence intervals resample blocks of markets rather than treating 500 ms forecasts as independent observations.

Market files must be consecutive and unfiltered whenever possible. Keep different model versions and forecast horizons in separate tests.

## 4. Models tested

Let:

```text
C = current Chainlink price
L = existing projected Chainlink price
F = current futures price
lag_move = L - C
```

The script constructs a prior-only normal futures/Chainlink basis and then calculates:

```text
basis_implied_chainlink = F / (1 + normal_basis_bps / 10,000)
basis_move = basis_implied_chainlink - C
```

It tests:

### No-change baseline

```text
prediction = C
```

### Existing lag projection

```text
prediction = L
```

### Calibrated lag

```text
prediction = C + a * lag_move
```

The scale `a` is learned on earlier markets under absolute error. This determines whether the existing projection is systematically too aggressive or too weak.

### Scaled basis-only model

```text
prediction = C + b * basis_move
```

This is primarily a diagnostic. It shows whether the basis has predictive value without the existing lag signal.

### Direct convex combination

```text
prediction = C + a * lag_move + b * basis_move

a >= 0
b >= 0
a + b <= 1
```

The remaining weight, `1 - a - b`, is shrinkage toward the current Chainlink price.

### Basis-confirmed gated lag

The script classifies each forecast as:

```text
agreement:
    lag and basis are both large enough and have the same sign

disagreement:
    lag and basis are both large enough and have opposite signs

neutral:
    at least one signal is too small to be considered active
```

It then fits separate lag scales:

```text
prediction = C + group_scale * lag_move
```

This tests whether the basis is more useful as confirmation than as a second price forecast.

## 5. Two basis constructions

The data chooses among both methods during chronological validation.

### `row`

Uses the prior rolling mean or median of:

```text
10,000 * (current futures / current Chainlink - 1)
```

It is strictly prior-only, but repeated rows can overweight a stale Chainlink observation. This method is included because it can work well as a real-time gap/confirmation feature.

### `synchronized`

For each unique Chainlink source timestamp, it matches the latest sampled futures quote whose source timestamp is no later than that Chainlink timestamp. The basis observation becomes available only after both quotes have been received.

This better estimates the structural futures basis. The JSON files contain only sampled futures observations, however. If the backend has the raw futures tick tape, replace the sampled tape in `build_synchronized_basis_events()` with the raw tape for a more exact as-of match.

## 6. Outputs

The output directory contains:

```text
report.md
selected_models.json
cv_candidate_summary.csv
cv_market_scores.csv
cv_fitted_parameters.csv
holdout_metrics_all_rows.csv
holdout_metrics_nonoverlap.csv
holdout_per_market.csv
holdout_predictions.csv
markets_loaded.csv
```

The most important files are:

- `report.md`: readable summary.
- `selected_models.json`: selected configuration and fitted coefficients.
- `holdout_metrics_nonoverlap.csv`: less-dependent final metrics.
- `holdout_per_market.csv`: market-by-market consistency.
- `holdout_predictions.csv`: every held-out prediction and error for debugging.

## 7. How to decide whether to deploy the basis signal

Use calibrated lag as the main benchmark, not only the original lag projection.

A basis model is strongly supported when all of the following hold on the final untouched markets:

1. Its MAE is below calibrated lag on the non-overlapping sample.
2. Its p95 absolute error and RMSE are not worse.
3. The market-block bootstrap comparison against `scaled_lag` has `ci_high < 0`.
4. It wins in a majority of held-out markets, preferably well above 50%.
5. The selected window, threshold, and coefficients are reasonably stable in `cv_fitted_parameters.csv`.
6. The result repeats in separated sessions, not only one contiguous market regime.

Interpret the block-bootstrap delta as:

```text
delta = challenger market MAE - calibrated-lag market MAE
```

Therefore:

```text
negative delta = challenger is better
positive delta = calibrated lag is better
```

If the validation winner is a hybrid but the default `one_se` selection is `scaled_lag`, the evidence for the extra basis complexity is still weak. Keep the hybrid as a shadow challenger rather than replacing the production model.

## 8. Suggested first production implementation

After the test selects a gated model, the online logic is:

```python
lag_move = lag_projection - current_chainlink
basis_move = basis_implied_chainlink - current_chainlink

lag_bps = 10_000 * lag_move / current_chainlink
basis_bps = 10_000 * basis_move / current_chainlink

both_active = (
    abs(lag_bps) >= gate_threshold_bps
    and abs(basis_bps) >= gate_threshold_bps
)

if both_active and sign(lag_bps) == sign(basis_bps):
    scale = agree_lag_scale
elif both_active:
    scale = disagree_lag_scale
else:
    scale = neutral_lag_scale

prediction = current_chainlink + scale * lag_move
```

Use values from `selected_models.json`; do not copy coefficients from the earlier 20-market experiment.

## 9. Important checks

- Use a narrow file pattern so rounded and unrounded exports of the same market are not both loaded. The script stops on duplicate market IDs.
- Do not shuffle markets.
- Do not tune on the final holdout after seeing its results.
- Do not calculate the normal basis from the complete market or complete dataset.
- Do not treat the 500 ms rows as independent statistical samples.
- Preserve warm-up history before the first evaluated market when testing separate data blocks.
- When comparing separate model versions, run separate backtests rather than mixing their predictions.

## 10. Smaller diagnostic run

A reduced parameter search is useful for checking paths and schemas:

```powershell
python .\chainlink_hybrid_backtest.py `
  --input-dir "C:\path\to\markets" `
  --output-dir ".\chainlink_hybrid_smoke_test" `
  --basis-methods "row" `
  --basis-estimators "median" `
  --basis-windows "60,120" `
  --gate-thresholds-bps "0.5,0.75,1.0" `
  --bootstrap-repetitions 500
```

Use the full recommended search for the actual model decision.
