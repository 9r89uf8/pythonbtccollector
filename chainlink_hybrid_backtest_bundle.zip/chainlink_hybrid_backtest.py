#!/usr/bin/env python3
"""Leakage-resistant backtest for short-horizon Chainlink BTC forecasts.

The script compares:
  1. Current Chainlink/no-change baseline.
  2. Existing lag projection.
  3. Calibrated lag projection.
  4. Direct convex lag+basis blend.
  5. Basis-confirmed gated lag model.

It is designed for JSON files with the schema used by
btc_5m_market_*_shadow_evaluations_*.json.

Main safeguards:
  * Markets are sorted chronologically.
  * The final markets are held out completely.
  * Split boundaries are purged using generation and outcome-receipt times.
  * Hyperparameters are selected with expanding-window validation.
  * Rolling basis estimates use only observations available before forecast time.
  * Fitting uses one forecast per horizon to reduce overlap.
  * Statistical comparisons are bootstrapped in market blocks, not by 500 ms row.

Dependencies: numpy, pandas
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import pandas as pd


PRICE_COLUMNS = (
    "chainlink_at_forecast",
    "futures_at_forecast",
    "projected_chainlink",
    "actual_chainlink",
)

INTEGER_COLUMNS = (
    "generated_ms",
    "target_ms",
    "matured_ms",
    "horizon_ms",
    "chainlink_at_forecast_source_timestamp_ms",
    "chainlink_at_forecast_received_ms",
    "futures_at_forecast_source_timestamp_ms",
    "futures_at_forecast_received_ms",
    "actual_chainlink_source_timestamp_ms",
    "actual_chainlink_received_ms",
)


@dataclass(frozen=True)
class BasisConfig:
    method: str  # row or synchronized
    estimator: str  # median or mean
    window_seconds: int

    @property
    def key(self) -> str:
        return f"{self.method}_{self.estimator}_{self.window_seconds}s"


@dataclass(frozen=True)
class Candidate:
    family: str  # scaled_lag, scaled_basis, convex, gated
    basis: BasisConfig | None = None
    gate_threshold_bps: float | None = None

    @property
    def key(self) -> str:
        if self.family == "scaled_lag":
            return "scaled_lag"
        if self.family == "scaled_basis" and self.basis is not None:
            return f"scaled_basis__{self.basis.key}"
        if self.family == "convex" and self.basis is not None:
            return f"convex__{self.basis.key}"
        if self.family == "gated" and self.basis is not None:
            threshold = format(self.gate_threshold_bps or 0.0, "g")
            return f"gated__{self.basis.key}__threshold_{threshold}bps"
        raise ValueError(f"Invalid candidate: {self}")

    @property
    def complexity(self) -> int:
        # Used only by the one-standard-error selection rule.
        return {"scaled_lag": 0, "scaled_basis": 1, "convex": 1, "gated": 2}[self.family]


@dataclass
class FittedModel:
    candidate_key: str
    family: str
    basis_key: str | None
    parameters: dict[str, float]


@dataclass
class SplitPlan:
    development_markets: list[int]
    test_markets: list[int]
    folds: list[dict[str, list[int]]]


class BacktestError(RuntimeError):
    pass


def parse_csv_ints(value: str) -> list[int]:
    try:
        result = [int(item.strip()) for item in value.split(",") if item.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc
    if not result:
        raise argparse.ArgumentTypeError("Expected at least one integer.")
    return result


def parse_csv_floats(value: str) -> list[float]:
    try:
        result = [float(item.strip()) for item in value.split(",") if item.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc
    if not result:
        raise argparse.ArgumentTypeError("Expected at least one number.")
    return result


def parse_csv_strings(value: str) -> list[str]:
    result = [item.strip().lower() for item in value.split(",") if item.strip()]
    if not result:
        raise argparse.ArgumentTypeError("Expected at least one value.")
    return result


def weighted_mean(values: np.ndarray, weights: np.ndarray) -> float:
    mask = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if not np.any(mask):
        return float("nan")
    return float(np.average(values[mask], weights=weights[mask]))


def weighted_median(values: np.ndarray, weights: np.ndarray) -> float:
    mask = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if not np.any(mask):
        return float("nan")
    values = values[mask]
    weights = weights[mask]
    order = np.argsort(values, kind="mergesort")
    values = values[order]
    weights = weights[order]
    cutoff = weights.sum() / 2.0
    index = int(np.searchsorted(np.cumsum(weights), cutoff, side="left"))
    return float(values[min(index, len(values) - 1)])


def fit_l1_scale(
    x: np.ndarray,
    y: np.ndarray,
    sample_weight: np.ndarray,
    lower: float = 0.0,
    upper: float = 1.5,
    fallback: float = 0.0,
) -> float:
    """Fit y ~= scale*x under weighted absolute error.

    For a regression through the origin, the L1 optimum is the weighted median
    of y/x with weights sample_weight*abs(x).
    """
    mask = (
        np.isfinite(x)
        & np.isfinite(y)
        & np.isfinite(sample_weight)
        & (sample_weight > 0)
        & (np.abs(x) > 1e-12)
    )
    if not np.any(mask):
        return float(fallback)
    ratios = y[mask] / x[mask]
    ratio_weights = sample_weight[mask] * np.abs(x[mask])
    result = weighted_median(ratios, ratio_weights)
    if not np.isfinite(result):
        return float(fallback)
    return float(np.clip(result, lower, upper))


def _simplex_grid(step: float) -> Iterable[tuple[float, float]]:
    n = int(round(1.0 / step))
    for i in range(n + 1):
        lag_weight = i * step
        max_j = n - i
        for j in range(max_j + 1):
            basis_weight = j * step
            yield lag_weight, basis_weight


def fit_convex_l1(
    lag_move: np.ndarray,
    basis_move: np.ndarray,
    actual_move: np.ndarray,
    sample_weight: np.ndarray,
    fallback_lag_scale: float,
) -> tuple[float, float]:
    """Fit actual_move ~= a*lag_move + b*basis_move, a,b>=0, a+b<=1."""
    mask = (
        np.isfinite(lag_move)
        & np.isfinite(basis_move)
        & np.isfinite(actual_move)
        & np.isfinite(sample_weight)
        & (sample_weight > 0)
    )
    if int(mask.sum()) < 25:
        return float(np.clip(fallback_lag_scale, 0.0, 1.0)), 0.0

    x_lag = lag_move[mask]
    x_basis = basis_move[mask]
    y = actual_move[mask]
    weights = sample_weight[mask]

    best_loss = float("inf")
    best = (float(np.clip(fallback_lag_scale, 0.0, 1.0)), 0.0)

    # Coarse simplex search.
    for a, b in _simplex_grid(0.05):
        loss = weighted_mean(np.abs(y - a * x_lag - b * x_basis), weights)
        if loss < best_loss:
            best_loss = loss
            best = (a, b)

    # Fine local search around the coarse optimum.
    a0, b0 = best
    a_values = np.arange(max(0.0, a0 - 0.06), min(1.0, a0 + 0.0601) + 1e-12, 0.01)
    b_values = np.arange(max(0.0, b0 - 0.06), min(1.0, b0 + 0.0601) + 1e-12, 0.01)
    for a in a_values:
        for b in b_values:
            if a + b > 1.0000001:
                continue
            loss = weighted_mean(np.abs(y - a * x_lag - b * x_basis), weights)
            if loss < best_loss:
                best_loss = loss
                best = (float(a), float(b))

    return best


def market_equal_weights(market_ids: np.ndarray) -> np.ndarray:
    series = pd.Series(market_ids)
    counts = series.value_counts(dropna=False)
    return series.map(lambda value: 1.0 / float(counts.loc[value])).to_numpy(dtype=float)


def selection_identity_key(model: dict[str, Any]) -> tuple[str, str, str]:
    identities = model.get("selection_identities") or []
    if not identities:
        return ("missing", "missing", "missing")
    identity = identities[0] or {}
    return (
        str(identity.get("policy_version", "missing")),
        str(identity.get("fingerprint_sha256", "missing")),
        str(identity.get("artifact_sha256", "missing")),
    )


def load_market_files(
    input_dir: Path,
    pattern: str,
    allow_mixed_models: bool,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    paths = sorted(input_dir.glob(pattern))
    if not paths:
        raise BacktestError(f"No files matched {input_dir / pattern}")

    rows: list[dict[str, Any]] = []
    market_records: list[dict[str, Any]] = []
    seen_market_ids: dict[int, Path] = {}

    for path in paths:
        try:
            with path.open("r", encoding="utf-8") as handle:
                payload = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            raise BacktestError(f"Failed to read {path}: {exc}") from exc

        try:
            market = payload["market"]
            model = payload["model"]
            points = payload["points"]
            market_id = int(market["market_id"])
            market_start_ms = int(market["market_start_ms"])
            market_end_ms = int(market["market_end_ms"])
        except (KeyError, TypeError, ValueError) as exc:
            raise BacktestError(f"Unexpected JSON structure in {path}: {exc}") from exc

        if market_id in seen_market_ids:
            raise BacktestError(
                f"Duplicate market_id {market_id}: {seen_market_ids[market_id]} and {path}. "
                "Use a narrower --pattern or remove duplicate exports."
            )
        seen_market_ids[market_id] = path

        market_records.append(
            {
                "market_id": market_id,
                "market_start_ms": market_start_ms,
                "market_end_ms": market_end_ms,
                "model_version": str(model.get("model_version", "")),
                "model_beta": str(model.get("beta", "")),
                "horizon_ms": int(model.get("horizon_ms", 0) or 0),
                "evaluation_cadence_ms": int(model.get("evaluation_cadence_ms", 0) or 0),
                "selection_policy_version": selection_identity_key(model)[0],
                "selection_fingerprint": selection_identity_key(model)[1],
                "selection_artifact_sha256": selection_identity_key(model)[2],
                "path": str(path),
                "point_count": len(points),
            }
        )

        for point_index, point in enumerate(points):
            row: dict[str, Any] = {
                "market_id": market_id,
                "market_start_ms": market_start_ms,
                "market_end_ms": market_end_ms,
                "source_file": str(path),
                "point_index": point_index,
                "valid": bool(point.get("valid", False)),
                "status": point.get("status"),
                "outcome_status": point.get("outcome_status"),
                "forecast_market_id": point.get("forecast_market_id"),
                "full_horizon_before_forecast_market_end": point.get(
                    "full_horizon_before_forecast_market_end"
                ),
            }
            for column in PRICE_COLUMNS + INTEGER_COLUMNS:
                row[column] = point.get(column)
            rows.append(row)

    markets = pd.DataFrame(market_records).sort_values(
        ["market_start_ms", "market_id"], kind="mergesort"
    )
    if not allow_mixed_models and markets["model_version"].nunique(dropna=False) > 1:
        versions = markets.groupby("model_version")["market_id"].count().to_dict()
        raise BacktestError(
            f"Mixed model versions found: {versions}. Use --allow-mixed-models only if intentional."
        )
    if not allow_mixed_models and markets["horizon_ms"].nunique(dropna=False) > 1:
        horizons = markets.groupby("horizon_ms")["market_id"].count().to_dict()
        raise BacktestError(
            f"Mixed forecast horizons found: {horizons}. Separate them before testing."
        )
    if not allow_mixed_models and markets["evaluation_cadence_ms"].nunique(dropna=False) > 1:
        cadences = markets.groupby("evaluation_cadence_ms")["market_id"].count().to_dict()
        raise BacktestError(
            f"Mixed evaluation cadences found: {cadences}. Separate them before testing."
        )
    if not allow_mixed_models and markets["model_beta"].nunique(dropna=False) > 1:
        betas = markets.groupby("model_beta")["market_id"].count().to_dict()
        raise BacktestError(
            f"Mixed model beta values found: {betas}. Separate them before testing."
        )
    if not allow_mixed_models and markets["selection_fingerprint"].nunique(dropna=False) > 1:
        fingerprints = markets.groupby("selection_fingerprint")["market_id"].count().to_dict()
        raise BacktestError(
            f"Mixed selection fingerprints found: {fingerprints}. Use a clean cohort."
        )

    frame = pd.DataFrame(rows)
    for column in PRICE_COLUMNS:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    for column in INTEGER_COLUMNS:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")

    frame = frame.sort_values(["generated_ms", "market_id", "point_index"], kind="mergesort")
    frame = frame.reset_index(drop=True)
    frame["row_id"] = np.arange(len(frame), dtype=np.int64)

    frame["scored"] = (
        frame["valid"]
        & frame["outcome_status"].eq("available")
        & frame[list(PRICE_COLUMNS)].notna().all(axis=1)
        & frame["generated_ms"].notna()
        & frame["target_ms"].notna()
    )

    # These are useful diagnostics and also stop accidental future-input leakage.
    frame["future_futures_source"] = (
        frame["futures_at_forecast_source_timestamp_ms"].notna()
        & (frame["futures_at_forecast_source_timestamp_ms"] > frame["generated_ms"])
    )
    frame["future_chainlink_source"] = (
        frame["chainlink_at_forecast_source_timestamp_ms"].notna()
        & (frame["chainlink_at_forecast_source_timestamp_ms"] > frame["generated_ms"])
    )
    frame["input_received_after_generation"] = (
        (
            frame["futures_at_forecast_received_ms"].notna()
            & (frame["futures_at_forecast_received_ms"] > frame["generated_ms"])
        )
        | (
            frame["chainlink_at_forecast_received_ms"].notna()
            & (frame["chainlink_at_forecast_received_ms"] > frame["generated_ms"])
        )
    )

    leakage_rows = (
        frame["future_futures_source"]
        | frame["future_chainlink_source"]
        | frame["input_received_after_generation"]
    )
    frame.loc[leakage_rows, "scored"] = False
    frame["input_valid"] = (
        ~leakage_rows
        & frame[
            [
                "generated_ms",
                "chainlink_at_forecast",
                "chainlink_at_forecast_source_timestamp_ms",
                "chainlink_at_forecast_received_ms",
                "futures_at_forecast",
                "futures_at_forecast_source_timestamp_ms",
                "futures_at_forecast_received_ms",
            ]
        ].notna().all(axis=1)
    )

    frame["current_price"] = frame["chainlink_at_forecast"]
    frame["lag_projection"] = frame["projected_chainlink"]
    frame["actual_price"] = frame["actual_chainlink"]
    frame["lag_move"] = frame["lag_projection"] - frame["current_price"]
    frame["actual_move"] = frame["actual_price"] - frame["current_price"]
    frame["lag_move_bps"] = 10_000.0 * frame["lag_move"] / frame["current_price"]
    frame["actual_move_bps"] = 10_000.0 * frame["actual_move"] / frame["current_price"]

    return frame, markets.reset_index(drop=True)


def build_synchronized_basis_events(frame: pd.DataFrame) -> pd.DataFrame:
    """Approximate a synchronized structural basis from the sampled JSON quotes.

    Each unique Chainlink source observation is matched to the latest sampled
    futures quote whose source timestamp is no later than the Chainlink source
    timestamp. The basis observation becomes usable only after both quotes have
    been received.

    If the backend has a raw futures tick tape, use that instead of the sampled
    futures quotes in these JSON files for a more exact as-of match.
    """
    input_frame = frame.loc[frame["input_valid"]].copy()

    chain = input_frame[
        [
            "chainlink_at_forecast_source_timestamp_ms",
            "chainlink_at_forecast_received_ms",
            "chainlink_at_forecast",
        ]
    ].dropna()
    chain = chain.sort_values(
        ["chainlink_at_forecast_source_timestamp_ms", "chainlink_at_forecast_received_ms"],
        kind="mergesort",
    ).drop_duplicates("chainlink_at_forecast_source_timestamp_ms", keep="first")

    futures = input_frame[
        [
            "futures_at_forecast_source_timestamp_ms",
            "futures_at_forecast_received_ms",
            "futures_at_forecast",
        ]
    ].dropna()
    futures = futures.sort_values(
        ["futures_at_forecast_source_timestamp_ms", "futures_at_forecast_received_ms"],
        kind="mergesort",
    ).drop_duplicates("futures_at_forecast_source_timestamp_ms", keep="first")

    if chain.empty or futures.empty:
        return pd.DataFrame(columns=["available_ms", "synchronized_basis_bps"])

    events = pd.merge_asof(
        chain.sort_values("chainlink_at_forecast_source_timestamp_ms"),
        futures.sort_values("futures_at_forecast_source_timestamp_ms"),
        left_on="chainlink_at_forecast_source_timestamp_ms",
        right_on="futures_at_forecast_source_timestamp_ms",
        direction="backward",
        allow_exact_matches=True,
    ).dropna()

    if events.empty:
        return pd.DataFrame(columns=["available_ms", "synchronized_basis_bps"])

    events["available_ms"] = events[
        ["chainlink_at_forecast_received_ms", "futures_at_forecast_received_ms"]
    ].max(axis=1).astype(np.int64)
    events["synchronized_basis_bps"] = 10_000.0 * (
        events["futures_at_forecast"] / events["chainlink_at_forecast"] - 1.0
    )
    events = events.replace([np.inf, -np.inf], np.nan).dropna(
        subset=["available_ms", "synchronized_basis_bps"]
    )
    events = events.sort_values(
        ["available_ms", "chainlink_at_forecast_source_timestamp_ms"], kind="mergesort"
    )
    return events.reset_index(drop=True)


def rolling_aggregate(
    values: np.ndarray,
    times_ms: np.ndarray,
    window_seconds: int,
    estimator: str,
    min_periods: int,
    closed: str | None = None,
) -> np.ndarray:
    series = pd.Series(
        values,
        index=pd.to_datetime(times_ms.astype(np.int64), unit="ms", utc=True),
        dtype=float,
    )
    rolling = series.rolling(
        f"{window_seconds}s",
        min_periods=min_periods,
        closed=closed,
    )
    if estimator == "median":
        return rolling.median().to_numpy(dtype=float)
    if estimator == "mean":
        return rolling.mean().to_numpy(dtype=float)
    raise ValueError(f"Unsupported estimator: {estimator}")


def make_basis_move(
    frame: pd.DataFrame,
    synchronized_events: pd.DataFrame,
    config: BasisConfig,
    min_basis_events: int,
) -> np.ndarray:
    current = frame["current_price"].to_numpy(dtype=float)
    futures_now = frame["futures_at_forecast"].to_numpy(dtype=float)
    generated_ms = frame["generated_ms"].to_numpy(dtype=float)

    if config.method == "row":
        current_basis_bps = 10_000.0 * (futures_now / current - 1.0)
        current_basis_bps[~frame["input_valid"].to_numpy(dtype=bool)] = np.nan
        normal_basis_bps = rolling_aggregate(
            values=current_basis_bps,
            times_ms=generated_ms,
            window_seconds=config.window_seconds,
            estimator=config.estimator,
            min_periods=min_basis_events,
            closed="left",  # strict prior-only normal basis
        )
    elif config.method == "synchronized":
        if synchronized_events.empty:
            return np.full(len(frame), np.nan, dtype=float)
        events = synchronized_events.copy()
        event_normal = rolling_aggregate(
            values=events["synchronized_basis_bps"].to_numpy(dtype=float),
            times_ms=events["available_ms"].to_numpy(dtype=np.int64),
            window_seconds=config.window_seconds,
            estimator=config.estimator,
            min_periods=min_basis_events,
            closed=None,  # include event itself; as-of join below is strictly before forecast
        )
        right = pd.DataFrame(
            {
                "available_ms": events["available_ms"].to_numpy(dtype=np.int64),
                "normal_basis_bps": event_normal,
            }
        ).sort_values("available_ms", kind="mergesort")
        left = frame[["row_id", "generated_ms"]].copy()
        left["generated_ms"] = left["generated_ms"].astype(np.int64)
        left = left.sort_values("generated_ms", kind="mergesort")
        joined = pd.merge_asof(
            left,
            right,
            left_on="generated_ms",
            right_on="available_ms",
            direction="backward",
            allow_exact_matches=False,
        ).sort_values("row_id", kind="mergesort")
        normal_basis_bps = joined["normal_basis_bps"].to_numpy(dtype=float)
    else:
        raise ValueError(f"Unsupported basis method: {config.method}")

    denominator = 1.0 + normal_basis_bps / 10_000.0
    with np.errstate(divide="ignore", invalid="ignore"):
        basis_implied_price = futures_now / denominator
        basis_move = basis_implied_price - current
    basis_move[~np.isfinite(basis_move)] = np.nan
    return basis_move


def greedy_non_overlapping_mask(frame: pd.DataFrame, spacing_ms: int) -> np.ndarray:
    mask = np.zeros(len(frame), dtype=bool)
    last_time = -10**30
    for index, (is_scored, generated_ms) in enumerate(
        zip(frame["scored"].to_numpy(dtype=bool), frame["generated_ms"].to_numpy())
    ):
        if not is_scored or not np.isfinite(generated_ms):
            continue
        timestamp = int(generated_ms)
        if timestamp - last_time >= spacing_ms:
            mask[index] = True
            last_time = timestamp
    return mask


def build_split_plan(
    market_ids: Sequence[int],
    test_markets: int,
    test_fraction: float,
    min_train_markets: int,
    validation_block_markets: int,
    validation_step_markets: int,
) -> SplitPlan:
    market_ids = list(market_ids)
    n_markets = len(market_ids)
    if n_markets < 8:
        raise BacktestError("At least 8 markets are required for chronological validation.")

    if test_markets <= 0:
        test_markets = max(2, int(round(n_markets * test_fraction)))
    test_markets = min(test_markets, n_markets - 4)

    development = market_ids[:-test_markets]
    test = market_ids[-test_markets:]

    if len(development) < 4:
        raise BacktestError("Too few development markets after creating the final holdout.")

    validation_block_markets = max(1, min(validation_block_markets, len(development) // 2))
    validation_step_markets = max(1, validation_step_markets)
    min_train_markets = max(2, min(min_train_markets, len(development) - validation_block_markets))

    folds: list[dict[str, list[int]]] = []
    train_end = min_train_markets
    while train_end + validation_block_markets <= len(development):
        folds.append(
            {
                "train": development[:train_end],
                "validation": development[train_end : train_end + validation_block_markets],
            }
        )
        train_end += validation_step_markets

    if not folds:
        split = max(2, len(development) - validation_block_markets)
        folds.append(
            {
                "train": development[:split],
                "validation": development[split:],
            }
        )

    return SplitPlan(development, test, folds)


def prediction_metrics(actual: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    error = predicted - actual
    mask = np.isfinite(error)
    if not np.any(mask):
        return {
            "n": 0,
            "mae": float("nan"),
            "rmse": float("nan"),
            "median_ae": float("nan"),
            "p95_ae": float("nan"),
            "bias": float("nan"),
        }
    error = error[mask]
    absolute = np.abs(error)
    return {
        "n": int(mask.sum()),
        "mae": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(np.square(error)))),
        "median_ae": float(np.median(absolute)),
        "p95_ae": float(np.quantile(absolute, 0.95)),
        "bias": float(np.mean(error)),
    }


def directional_metrics(
    current: np.ndarray,
    actual: np.ndarray,
    predicted: np.ndarray,
    deadband_bps: float,
) -> dict[str, float]:
    actual_move_bps = 10_000.0 * (actual - current) / current
    predicted_move_bps = 10_000.0 * (predicted - current) / current
    actual_active = np.isfinite(actual_move_bps) & (np.abs(actual_move_bps) >= deadband_bps)
    predicted_active = np.isfinite(predicted_move_bps) & (
        np.abs(predicted_move_bps) >= deadband_bps
    )
    eligible = actual_active & predicted_active
    if not np.any(eligible):
        return {
            "direction_n": 0,
            "direction_accuracy": float("nan"),
            "direction_coverage": 0.0,
        }
    correct = np.sign(actual_move_bps[eligible]) == np.sign(predicted_move_bps[eligible])
    denominator = max(int(actual_active.sum()), 1)
    return {
        "direction_n": int(eligible.sum()),
        "direction_accuracy": float(np.mean(correct)),
        "direction_coverage": float(eligible.sum() / denominator),
    }


def per_market_mae(
    market_ids: np.ndarray,
    actual: np.ndarray,
    predicted: np.ndarray,
) -> pd.DataFrame:
    temp = pd.DataFrame(
        {
            "market_id": market_ids,
            "absolute_error": np.abs(predicted - actual),
        }
    ).replace([np.inf, -np.inf], np.nan)
    temp = temp.dropna(subset=["market_id", "absolute_error"])
    return (
        temp.groupby("market_id", as_index=False)
        .agg(mae=("absolute_error", "mean"), n=("absolute_error", "size"))
        .sort_values("market_id", kind="mergesort")
    )


def gate_categories(
    lag_move: np.ndarray,
    basis_move: np.ndarray,
    current_price: np.ndarray,
    threshold_bps: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    lag_bps = 10_000.0 * lag_move / current_price
    basis_bps = 10_000.0 * basis_move / current_price
    both_active = (
        np.isfinite(lag_bps)
        & np.isfinite(basis_bps)
        & (np.abs(lag_bps) >= threshold_bps)
        & (np.abs(basis_bps) >= threshold_bps)
    )
    agree = both_active & (np.sign(lag_bps) == np.sign(basis_bps))
    disagree = both_active & (np.sign(lag_bps) != np.sign(basis_bps))
    neutral = ~(agree | disagree)
    return agree, neutral, disagree


def fit_candidate(
    candidate: Candidate,
    frame: pd.DataFrame,
    basis_cache: dict[BasisConfig, np.ndarray],
    train_mask: np.ndarray,
    minimum_gate_group_points: int,
) -> FittedModel:
    lag = frame["lag_move"].to_numpy(dtype=float)
    y = frame["actual_move"].to_numpy(dtype=float)
    markets = frame["market_id"].to_numpy(dtype=int)
    current = frame["current_price"].to_numpy(dtype=float)

    train_indices = np.flatnonzero(train_mask)
    weights = market_equal_weights(markets[train_indices])
    global_scale = fit_l1_scale(lag[train_indices], y[train_indices], weights, 0.0, 1.5, 0.0)

    if candidate.family == "scaled_lag":
        return FittedModel(
            candidate_key=candidate.key,
            family="scaled_lag",
            basis_key=None,
            parameters={"lag_scale": global_scale},
        )

    if candidate.basis is None:
        raise ValueError(f"Candidate {candidate.key} requires a basis configuration.")
    basis = basis_cache[candidate.basis]

    if candidate.family == "scaled_basis":
        finite = train_mask & np.isfinite(basis)
        finite_indices = np.flatnonzero(finite)
        finite_weights = (
            market_equal_weights(markets[finite_indices]) if len(finite_indices) else np.array([])
        )
        basis_scale = fit_l1_scale(
            basis[finite_indices],
            y[finite_indices],
            finite_weights,
            0.0,
            1.5,
            0.0,
        )
        return FittedModel(
            candidate_key=candidate.key,
            family="scaled_basis",
            basis_key=candidate.basis.key,
            parameters={"basis_scale": basis_scale},
        )

    if candidate.family == "convex":
        finite = train_mask & np.isfinite(basis)
        finite_indices = np.flatnonzero(finite)
        finite_weights = market_equal_weights(markets[finite_indices]) if len(finite_indices) else np.array([])
        lag_weight, basis_weight = fit_convex_l1(
            lag[finite_indices],
            basis[finite_indices],
            y[finite_indices],
            finite_weights,
            fallback_lag_scale=global_scale,
        )
        return FittedModel(
            candidate_key=candidate.key,
            family="convex",
            basis_key=candidate.basis.key,
            parameters={
                "lag_weight": lag_weight,
                "basis_weight": basis_weight,
                "current_weight": 1.0 - lag_weight - basis_weight,
                "missing_basis_lag_scale": global_scale,
            },
        )

    if candidate.family == "gated":
        threshold = float(candidate.gate_threshold_bps or 0.0)
        agree, neutral, disagree = gate_categories(lag, basis, current, threshold)

        def group_scale(group_mask: np.ndarray) -> float:
            mask = train_mask & group_mask
            indices = np.flatnonzero(mask)
            if len(indices) < minimum_gate_group_points:
                return global_scale
            group_weights = market_equal_weights(markets[indices])
            return fit_l1_scale(
                lag[indices],
                y[indices],
                group_weights,
                0.0,
                1.5,
                global_scale,
            )

        return FittedModel(
            candidate_key=candidate.key,
            family="gated",
            basis_key=candidate.basis.key,
            parameters={
                "gate_threshold_bps": threshold,
                "agree_lag_scale": group_scale(agree),
                "neutral_lag_scale": group_scale(neutral),
                "disagree_lag_scale": group_scale(disagree),
                "global_lag_scale": global_scale,
            },
        )

    raise ValueError(f"Unsupported family: {candidate.family}")


def predict_fitted(
    fitted: FittedModel,
    candidate: Candidate,
    frame: pd.DataFrame,
    basis_cache: dict[BasisConfig, np.ndarray],
) -> np.ndarray:
    current = frame["current_price"].to_numpy(dtype=float)
    lag = frame["lag_move"].to_numpy(dtype=float)

    if fitted.family == "scaled_lag":
        return current + fitted.parameters["lag_scale"] * lag

    if candidate.basis is None:
        raise ValueError("Basis candidate expected.")
    basis = basis_cache[candidate.basis]

    if fitted.family == "scaled_basis":
        prediction = current + fitted.parameters["basis_scale"] * basis
        prediction[~np.isfinite(basis)] = current[~np.isfinite(basis)]
        return prediction

    if fitted.family == "convex":
        prediction = (
            current
            + fitted.parameters["lag_weight"] * lag
            + fitted.parameters["basis_weight"] * basis
        )
        missing = ~np.isfinite(basis)
        prediction[missing] = (
            current[missing]
            + fitted.parameters["missing_basis_lag_scale"] * lag[missing]
        )
        return prediction

    if fitted.family == "gated":
        agree, neutral, disagree = gate_categories(
            lag,
            basis,
            current,
            fitted.parameters["gate_threshold_bps"],
        )
        scales = np.full(len(frame), fitted.parameters["neutral_lag_scale"], dtype=float)
        scales[agree] = fitted.parameters["agree_lag_scale"]
        scales[disagree] = fitted.parameters["disagree_lag_scale"]
        return current + scales * lag

    raise ValueError(f"Unsupported fitted family: {fitted.family}")


def candidate_from_key(key: str, candidates: Sequence[Candidate]) -> Candidate:
    for candidate in candidates:
        if candidate.key == key:
            return candidate
    raise KeyError(key)


def add_cv_market_scores(
    accumulator: dict[str, list[dict[str, Any]]],
    candidate: Candidate,
    fold_index: int,
    validation_market_ids: np.ndarray,
    actual: np.ndarray,
    predicted: np.ndarray,
) -> None:
    table = per_market_mae(validation_market_ids, actual, predicted)
    for row in table.itertuples(index=False):
        accumulator[candidate.key].append(
            {
                "candidate_key": candidate.key,
                "family": candidate.family,
                "basis_key": candidate.basis.key if candidate.basis else None,
                "gate_threshold_bps": candidate.gate_threshold_bps,
                "fold": fold_index,
                "market_id": int(row.market_id),
                "mae": float(row.mae),
                "n": int(row.n),
            }
        )


def summarize_cv_scores(
    score_rows: list[dict[str, Any]],
    candidates: Sequence[Candidate],
) -> pd.DataFrame:
    scores = pd.DataFrame(score_rows)
    if scores.empty:
        raise BacktestError("No validation scores were produced.")

    summary = (
        scores.groupby("candidate_key", as_index=False)
        .agg(
            cv_mean_market_mae=("mae", "mean"),
            cv_median_market_mae=("mae", "median"),
            cv_std_market_mae=("mae", "std"),
            validation_market_observations=("market_id", "size"),
            validation_markets=("market_id", "nunique"),
            folds=("fold", "nunique"),
        )
    )
    summary["cv_se_market_mae"] = summary["cv_std_market_mae"] / np.sqrt(
        summary["validation_market_observations"].clip(lower=1)
    )

    metadata = pd.DataFrame(
        [
            {
                "candidate_key": candidate.key,
                "family": candidate.family,
                "basis_method": candidate.basis.method if candidate.basis else None,
                "basis_estimator": candidate.basis.estimator if candidate.basis else None,
                "basis_window_seconds": candidate.basis.window_seconds if candidate.basis else None,
                "gate_threshold_bps": candidate.gate_threshold_bps,
                "complexity": candidate.complexity,
            }
            for candidate in candidates
        ]
    )
    summary = summary.merge(metadata, on="candidate_key", how="left")
    return summary.sort_values(
        ["cv_mean_market_mae", "complexity", "candidate_key"], kind="mergesort"
    ).reset_index(drop=True)


def select_candidate(cv_summary: pd.DataFrame, rule: str) -> str:
    best = cv_summary.iloc[0]
    if rule == "best":
        return str(best["candidate_key"])
    if rule != "one_se":
        raise ValueError(rule)

    threshold = float(best["cv_mean_market_mae"] + best["cv_se_market_mae"])
    eligible = cv_summary[cv_summary["cv_mean_market_mae"] <= threshold].copy()
    eligible = eligible.sort_values(
        ["complexity", "cv_mean_market_mae", "candidate_key"], kind="mergesort"
    )
    return str(eligible.iloc[0]["candidate_key"])


def moving_block_bootstrap_mean(
    differences: np.ndarray,
    repetitions: int,
    block_size: int,
    seed: int,
) -> dict[str, float]:
    differences = np.asarray(differences, dtype=float)
    differences = differences[np.isfinite(differences)]
    n = len(differences)
    if n == 0:
        return {
            "mean_delta": float("nan"),
            "ci_low": float("nan"),
            "ci_high": float("nan"),
            "probability_delta_below_zero": float("nan"),
        }
    if n == 1 or repetitions <= 0:
        mean = float(np.mean(differences))
        return {
            "mean_delta": mean,
            "ci_low": mean,
            "ci_high": mean,
            "probability_delta_below_zero": float(mean < 0),
        }

    block_size = max(1, min(block_size, n))
    if block_size >= n:
        block_size = max(1, n // 2)
    rng = np.random.default_rng(seed)
    starts = np.arange(n)
    bootstrap_means = np.empty(repetitions, dtype=float)

    for repetition in range(repetitions):
        sampled: list[float] = []
        while len(sampled) < n:
            start = int(rng.choice(starts))
            for offset in range(block_size):
                sampled.append(float(differences[(start + offset) % n]))
                if len(sampled) >= n:
                    break
        bootstrap_means[repetition] = float(np.mean(sampled))

    return {
        "mean_delta": float(np.mean(differences)),
        "ci_low": float(np.quantile(bootstrap_means, 0.025)),
        "ci_high": float(np.quantile(bootstrap_means, 0.975)),
        "probability_delta_below_zero": float(np.mean(bootstrap_means < 0.0)),
    }


def compare_models_by_market(
    per_market: pd.DataFrame,
    challenger: str,
    baseline: str,
    repetitions: int,
    block_size: int,
    seed: int,
) -> dict[str, Any]:
    challenger_rows = per_market[per_market["model"] == challenger][
        ["market_id", "mae"]
    ].rename(columns={"mae": "challenger_mae"})
    baseline_rows = per_market[per_market["model"] == baseline][
        ["market_id", "mae"]
    ].rename(columns={"mae": "baseline_mae"})
    paired = challenger_rows.merge(baseline_rows, on="market_id", how="inner").sort_values(
        "market_id", kind="mergesort"
    )
    paired["delta_mae"] = paired["challenger_mae"] - paired["baseline_mae"]
    result = moving_block_bootstrap_mean(
        paired["delta_mae"].to_numpy(dtype=float),
        repetitions=repetitions,
        block_size=block_size,
        seed=seed,
    )
    result.update(
        {
            "challenger": challenger,
            "baseline": baseline,
            "markets": int(len(paired)),
            "challenger_market_win_rate": float(np.mean(paired["delta_mae"] < 0.0))
            if len(paired)
            else float("nan"),
            "challenger_market_tie_rate": float(np.mean(paired["delta_mae"] == 0.0))
            if len(paired)
            else float("nan"),
        }
    )
    return result


def format_number(value: Any, digits: int = 6) -> str:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)
    if not np.isfinite(numeric):
        return "NA"
    return f"{numeric:.{digits}f}"


def write_markdown_report(
    output_path: Path,
    input_summary: dict[str, Any],
    split: SplitPlan,
    selection_rule: str,
    cv_best_key: str,
    selected_key: str,
    fitted_models: dict[str, FittedModel],
    overall_metrics: pd.DataFrame,
    nonoverlap_metrics: pd.DataFrame,
    comparisons: list[dict[str, Any]],
    cv_summary: pd.DataFrame,
) -> None:
    lines: list[str] = []
    lines.append("# Chainlink BTC hybrid backtest")
    lines.append("")
    lines.append("## Input and split")
    lines.append("")
    lines.append(f"- Markets loaded: {input_summary['markets_loaded']}")
    lines.append(f"- Scored rows: {input_summary['scored_rows']}")
    lines.append(f"- Excluded future-input rows: {input_summary['future_input_rows']}")
    lines.append("- Split-boundary purge: enabled (forecast generation and outcome receipt times)")
    lines.append(f"- Development markets: {len(split.development_markets)}")
    lines.append(f"- Final untouched test markets: {len(split.test_markets)}")
    lines.append(f"- Walk-forward validation folds: {len(split.folds)}")
    lines.append("")
    lines.append("## Model selection")
    lines.append("")
    lines.append(f"- CV-best candidate: `{cv_best_key}`")
    lines.append(f"- Selected by `{selection_rule}` rule: `{selected_key}`")
    lines.append("")
    for key, fitted in fitted_models.items():
        lines.append(f"### `{key}` fitted parameters")
        lines.append("")
        lines.append("```json")
        lines.append(json.dumps(asdict(fitted), indent=2, sort_keys=True))
        lines.append("```")
        lines.append("")

    def markdown_table(table: pd.DataFrame, columns: list[str]) -> list[str]:
        header = "| " + " | ".join(columns) + " |"
        divider = "|" + "|".join(["---" for _ in columns]) + "|"
        rows = [header, divider]
        for record in table[columns].to_dict(orient="records"):
            values = []
            for column in columns:
                value = record[column]
                if isinstance(value, (float, np.floating)):
                    values.append(format_number(value))
                else:
                    values.append(str(value))
            rows.append("| " + " | ".join(values) + " |")
        return rows

    lines.append("## Final holdout: all valid 500 ms rows")
    lines.append("")
    lines.extend(
        markdown_table(
            overall_metrics,
            [
                "model",
                "n",
                "mae",
                "rmse",
                "median_ae",
                "p95_ae",
                "bias",
                "direction_accuracy",
                "direction_coverage",
            ],
        )
    )
    lines.append("")
    lines.append("## Final holdout: one row per forecast horizon")
    lines.append("")
    lines.extend(
        markdown_table(
            nonoverlap_metrics,
            [
                "model",
                "n",
                "mae",
                "rmse",
                "median_ae",
                "p95_ae",
                "bias",
                "direction_accuracy",
                "direction_coverage",
            ],
        )
    )
    lines.append("")
    lines.append("## Market-block bootstrap comparisons")
    lines.append("")
    for comparison in comparisons:
        lines.append(
            "- `{challenger}` vs `{baseline}`: mean market MAE delta {delta}; "
            "95% block-bootstrap CI [{low}, {high}]; market win rate {win}.".format(
                challenger=comparison["challenger"],
                baseline=comparison["baseline"],
                delta=format_number(comparison["mean_delta"]),
                low=format_number(comparison["ci_low"]),
                high=format_number(comparison["ci_high"]),
                win=format_number(comparison["challenger_market_win_rate"]),
            )
        )
    lines.append("")
    lines.append("A negative delta favors the challenger. Treat the basis contribution as confirmed only when the upper confidence bound is below zero and tail error is not worse.")
    lines.append("")
    lines.append("## Top validation candidates")
    lines.append("")
    lines.extend(
        markdown_table(
            cv_summary.head(20),
            [
                "candidate_key",
                "family",
                "cv_mean_market_mae",
                "cv_se_market_mae",
                "validation_markets",
            ],
        )
    )
    lines.append("")
    output_path.write_text("\n".join(lines), encoding="utf-8")


def market_start_for_ids(markets: pd.DataFrame, market_ids: Sequence[int]) -> int:
    if not market_ids:
        raise BacktestError("Expected at least one market ID when constructing a split boundary.")
    first_id = int(market_ids[0])
    match = markets.loc[markets["market_id"] == first_id, "market_start_ms"]
    if match.empty:
        raise BacktestError(f"Market {first_id} is missing from market metadata.")
    return int(match.iloc[0])


def purged_train_validation_masks(
    frame: pd.DataFrame,
    markets: pd.DataFrame,
    scored_array: np.ndarray,
    nonoverlap_mask: np.ndarray,
    market_array: np.ndarray,
    train_market_ids: Sequence[int],
    validation_market_ids: Sequence[int],
) -> tuple[np.ndarray, np.ndarray]:
    """Create a strictly chronological fold.

    Training labels must have been received before the first validation forecast
    can be generated. Validation rows generated before their first market's
    official start are removed because these exports include a few boundary rows
    whose targets fall inside the market but whose forecasts were made earlier.
    """
    validation_start_ms = market_start_for_ids(markets, validation_market_ids)
    generated_ms = frame["generated_ms"].to_numpy(dtype=float)
    actual_received_ms = frame["actual_chainlink_received_ms"].to_numpy(dtype=float)

    train_mask = (
        scored_array
        & nonoverlap_mask
        & np.isin(market_array, np.asarray(train_market_ids, dtype=int))
        & np.isfinite(actual_received_ms)
        & (actual_received_ms < validation_start_ms)
    )
    validation_mask = (
        scored_array
        & nonoverlap_mask
        & np.isin(market_array, np.asarray(validation_market_ids, dtype=int))
        & np.isfinite(generated_ms)
        & (generated_ms >= validation_start_ms)
    )
    return train_mask, validation_mask


def run_backtest(args: argparse.Namespace) -> dict[str, Any]:
    input_dir = Path(args.input_dir).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    frame, markets = load_market_files(
        input_dir=input_dir,
        pattern=args.pattern,
        allow_mixed_models=args.allow_mixed_models,
    )

    ordered_market_ids = markets["market_id"].astype(int).tolist()
    horizon_values = markets.loc[markets["horizon_ms"] > 0, "horizon_ms"].unique()
    inferred_horizon_ms = int(horizon_values[0]) if len(horizon_values) == 1 else 3000
    spacing_ms = args.nonoverlap_spacing_ms or inferred_horizon_ms
    nonoverlap_mask = greedy_non_overlapping_mask(frame, spacing_ms)

    split = build_split_plan(
        market_ids=ordered_market_ids,
        test_markets=args.test_markets,
        test_fraction=args.test_fraction,
        min_train_markets=args.min_train_markets,
        validation_block_markets=args.validation_block_markets,
        validation_step_markets=args.validation_step_markets,
    )

    basis_methods = args.basis_methods
    basis_estimators = args.basis_estimators
    for value in basis_methods:
        if value not in {"row", "synchronized"}:
            raise BacktestError(f"Unsupported basis method: {value}")
    for value in basis_estimators:
        if value not in {"median", "mean"}:
            raise BacktestError(f"Unsupported basis estimator: {value}")

    basis_configs = [
        BasisConfig(method, estimator, window)
        for method in basis_methods
        for estimator in basis_estimators
        for window in args.basis_windows
    ]

    synchronized_events = build_synchronized_basis_events(frame)
    basis_cache: dict[BasisConfig, np.ndarray] = {}
    for config in basis_configs:
        basis_cache[config] = make_basis_move(
            frame,
            synchronized_events,
            config,
            min_basis_events=args.min_basis_events,
        )

    candidates: list[Candidate] = [Candidate("scaled_lag")]
    candidates.extend(Candidate("scaled_basis", basis=config) for config in basis_configs)
    candidates.extend(Candidate("convex", basis=config) for config in basis_configs)
    candidates.extend(
        Candidate("gated", basis=config, gate_threshold_bps=threshold)
        for config in basis_configs
        for threshold in args.gate_thresholds_bps
    )

    scored_array = frame["scored"].to_numpy(dtype=bool)
    market_array = frame["market_id"].to_numpy(dtype=int)
    actual_array = frame["actual_price"].to_numpy(dtype=float)

    score_accumulator: dict[str, list[dict[str, Any]]] = defaultdict(list)
    coefficient_rows: list[dict[str, Any]] = []

    for fold_index, fold in enumerate(split.folds):
        train_mask, validation_mask = purged_train_validation_masks(
            frame=frame,
            markets=markets,
            scored_array=scored_array,
            nonoverlap_mask=nonoverlap_mask,
            market_array=market_array,
            train_market_ids=fold["train"],
            validation_market_ids=fold["validation"],
        )
        if int(train_mask.sum()) < 20 or int(validation_mask.sum()) < 5:
            continue

        for candidate in candidates:
            fitted = fit_candidate(
                candidate,
                frame,
                basis_cache,
                train_mask,
                minimum_gate_group_points=args.minimum_gate_group_points,
            )
            predicted = predict_fitted(fitted, candidate, frame, basis_cache)
            val_indices = np.flatnonzero(validation_mask)
            add_cv_market_scores(
                score_accumulator,
                candidate,
                fold_index,
                market_array[val_indices],
                actual_array[val_indices],
                predicted[val_indices],
            )
            coefficient_rows.append(
                {
                    "fold": fold_index,
                    "candidate_key": candidate.key,
                    "train_market_count": len(fold["train"]),
                    "validation_market_count": len(fold["validation"]),
                    **fitted.parameters,
                }
            )

    all_score_rows = [row for rows in score_accumulator.values() for row in rows]
    cv_summary = summarize_cv_scores(all_score_rows, candidates)
    cv_best_key = str(cv_summary.iloc[0]["candidate_key"])
    selected_key = select_candidate(cv_summary, args.selection_rule)

    # Also carry the best candidate from each model family into the final comparison.
    family_best_keys: list[str] = []
    for family in ("scaled_lag", "scaled_basis", "convex", "gated"):
        family_rows = cv_summary[cv_summary["family"] == family]
        if not family_rows.empty:
            family_best_keys.append(str(family_rows.iloc[0]["candidate_key"]))
    final_candidate_keys = list(dict.fromkeys(["scaled_lag", *family_best_keys, cv_best_key, selected_key]))

    test_start_ms = market_start_for_ids(markets, split.test_markets)
    generated_ms_array = frame["generated_ms"].to_numpy(dtype=float)
    actual_received_ms_array = frame["actual_chainlink_received_ms"].to_numpy(dtype=float)
    development_train_mask = (
        scored_array
        & nonoverlap_mask
        & np.isin(market_array, np.asarray(split.development_markets, dtype=int))
        & np.isfinite(actual_received_ms_array)
        & (actual_received_ms_array < test_start_ms)
    )
    test_mask = (
        scored_array
        & np.isin(market_array, np.asarray(split.test_markets, dtype=int))
        & np.isfinite(generated_ms_array)
        & (generated_ms_array >= test_start_ms)
    )
    test_nonoverlap_mask = test_mask & nonoverlap_mask

    current = frame["current_price"].to_numpy(dtype=float)
    raw_lag_prediction = frame["lag_projection"].to_numpy(dtype=float)

    model_predictions: dict[str, np.ndarray] = {
        "no_change": current.copy(),
        "raw_lag": raw_lag_prediction.copy(),
    }
    fitted_models: dict[str, FittedModel] = {}

    for key in final_candidate_keys:
        candidate = candidate_from_key(key, candidates)
        fitted = fit_candidate(
            candidate,
            frame,
            basis_cache,
            development_train_mask,
            minimum_gate_group_points=args.minimum_gate_group_points,
        )
        fitted_models[key] = fitted
        model_predictions[key] = predict_fitted(fitted, candidate, frame, basis_cache)

    overall_metric_rows: list[dict[str, Any]] = []
    nonoverlap_metric_rows: list[dict[str, Any]] = []
    per_market_rows: list[dict[str, Any]] = []
    prediction_export = frame.loc[
        test_mask,
        [
            "market_id",
            "generated_ms",
            "target_ms",
            "current_price",
            "futures_at_forecast",
            "lag_projection",
            "actual_price",
            "lag_move",
            "actual_move",
        ],
    ].copy()

    for model_name, predicted_all in model_predictions.items():
        for mask, destination in (
            (test_mask, overall_metric_rows),
            (test_nonoverlap_mask, nonoverlap_metric_rows),
        ):
            indices = np.flatnonzero(mask)
            metrics = prediction_metrics(actual_array[indices], predicted_all[indices])
            metrics.update(
                directional_metrics(
                    current[indices],
                    actual_array[indices],
                    predicted_all[indices],
                    deadband_bps=args.direction_deadband_bps,
                )
            )
            metrics["model"] = model_name
            metrics["mean_market_mae"] = float(
                per_market_mae(
                    market_array[indices], actual_array[indices], predicted_all[indices]
                )["mae"].mean()
            )
            destination.append(metrics)

        indices = np.flatnonzero(test_mask)
        table = per_market_mae(
            market_array[indices], actual_array[indices], predicted_all[indices]
        )
        table["model"] = model_name
        per_market_rows.extend(table.to_dict(orient="records"))
        prediction_export[f"prediction__{model_name}"] = predicted_all[test_mask]
        prediction_export[f"error__{model_name}"] = predicted_all[test_mask] - actual_array[test_mask]

    overall_metrics = pd.DataFrame(overall_metric_rows).sort_values(
        ["mae", "model"], kind="mergesort"
    )
    nonoverlap_metrics = pd.DataFrame(nonoverlap_metric_rows).sort_values(
        ["mae", "model"], kind="mergesort"
    )
    per_market = pd.DataFrame(per_market_rows).sort_values(
        ["market_id", "model"], kind="mergesort"
    )

    comparisons: list[dict[str, Any]] = []
    for challenger in final_candidate_keys:
        if challenger == "scaled_lag":
            continue
        comparisons.append(
            compare_models_by_market(
                per_market,
                challenger=challenger,
                baseline="scaled_lag",
                repetitions=args.bootstrap_repetitions,
                block_size=args.bootstrap_block_markets,
                seed=args.seed + len(comparisons),
            )
        )
    comparisons.append(
        compare_models_by_market(
            per_market,
            challenger=selected_key,
            baseline="raw_lag",
            repetitions=args.bootstrap_repetitions,
            block_size=args.bootstrap_block_markets,
            seed=args.seed + 1000,
        )
    )

    future_input_rows = int(
        (
            frame["future_futures_source"]
            | frame["future_chainlink_source"]
            | frame["input_received_after_generation"]
        ).sum()
    )
    input_summary = {
        "input_dir": str(input_dir),
        "pattern": args.pattern,
        "markets_loaded": int(len(markets)),
        "rows_loaded": int(len(frame)),
        "scored_rows": int(frame["scored"].sum()),
        "invalid_or_unscored_rows": int((~frame["scored"]).sum()),
        "future_input_rows": future_input_rows,
        "synchronized_basis_events": int(len(synchronized_events)),
        "development_rows_after_boundary_purge": int(development_train_mask.sum()),
        "test_rows_after_boundary_purge": int(test_mask.sum()),
        "model_versions": markets["model_version"].value_counts().to_dict(),
        "model_betas": markets["model_beta"].value_counts().to_dict(),
        "horizons_ms": markets["horizon_ms"].value_counts().to_dict(),
        "evaluation_cadences_ms": markets["evaluation_cadence_ms"].value_counts().to_dict(),
        "selection_fingerprints": markets["selection_fingerprint"].value_counts().to_dict(),
    }

    # Save machine-readable outputs.
    markets.to_csv(output_dir / "markets_loaded.csv", index=False)
    cv_summary.to_csv(output_dir / "cv_candidate_summary.csv", index=False)
    pd.DataFrame(all_score_rows).to_csv(output_dir / "cv_market_scores.csv", index=False)
    pd.DataFrame(coefficient_rows).to_csv(output_dir / "cv_fitted_parameters.csv", index=False)
    overall_metrics.to_csv(output_dir / "holdout_metrics_all_rows.csv", index=False)
    nonoverlap_metrics.to_csv(output_dir / "holdout_metrics_nonoverlap.csv", index=False)
    per_market.to_csv(output_dir / "holdout_per_market.csv", index=False)
    prediction_export.to_csv(output_dir / "holdout_predictions.csv", index=False)

    model_payload = {
        "selection_rule": args.selection_rule,
        "cv_best_candidate": cv_best_key,
        "selected_candidate": selected_key,
        "fitted_models": {key: asdict(value) for key, value in fitted_models.items()},
        "split": asdict(split),
        "input_summary": input_summary,
        "comparisons": comparisons,
    }
    (output_dir / "selected_models.json").write_text(
        json.dumps(model_payload, indent=2, sort_keys=True), encoding="utf-8"
    )

    write_markdown_report(
        output_path=output_dir / "report.md",
        input_summary=input_summary,
        split=split,
        selection_rule=args.selection_rule,
        cv_best_key=cv_best_key,
        selected_key=selected_key,
        fitted_models=fitted_models,
        overall_metrics=overall_metrics,
        nonoverlap_metrics=nonoverlap_metrics,
        comparisons=comparisons,
        cv_summary=cv_summary,
    )

    return {
        "output_dir": str(output_dir),
        "input_summary": input_summary,
        "cv_best_candidate": cv_best_key,
        "selected_candidate": selected_key,
        "holdout_metrics_all_rows": overall_metrics.to_dict(orient="records"),
        "holdout_metrics_nonoverlap": nonoverlap_metrics.to_dict(orient="records"),
        "comparisons": comparisons,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Chronological backtest for combining lag and futures/Chainlink basis signals."
    )
    parser.add_argument("--input-dir", required=True, help="Directory containing market JSON files.")
    parser.add_argument(
        "--pattern",
        default="btc_5m_market_*_shadow_evaluations_*.json",
        help="Glob pattern inside --input-dir.",
    )
    parser.add_argument(
        "--output-dir",
        default="chainlink_hybrid_results",
        help="Directory for CSV, JSON, and Markdown outputs.",
    )
    parser.add_argument(
        "--test-markets",
        type=int,
        default=0,
        help="Number of final untouched markets. 0 uses --test-fraction.",
    )
    parser.add_argument("--test-fraction", type=float, default=0.20)
    parser.add_argument("--min-train-markets", type=int, default=40)
    parser.add_argument("--validation-block-markets", type=int, default=10)
    parser.add_argument("--validation-step-markets", type=int, default=10)
    parser.add_argument(
        "--basis-methods",
        type=parse_csv_strings,
        default=parse_csv_strings("row,synchronized"),
        help="Comma-separated: row,synchronized",
    )
    parser.add_argument(
        "--basis-estimators",
        type=parse_csv_strings,
        default=parse_csv_strings("median,mean"),
        help="Comma-separated: median,mean",
    )
    parser.add_argument(
        "--basis-windows",
        type=parse_csv_ints,
        default=parse_csv_ints("30,60,120,300,600"),
        help="Rolling basis windows in seconds.",
    )
    parser.add_argument(
        "--gate-thresholds-bps",
        type=parse_csv_floats,
        default=parse_csv_floats("0.25,0.5,0.75,1.0,1.5"),
        help="Both lag and basis moves must exceed this absolute bps threshold to be strongly active.",
    )
    parser.add_argument("--min-basis-events", type=int, default=20)
    parser.add_argument("--minimum-gate-group-points", type=int, default=25)
    parser.add_argument(
        "--selection-rule",
        choices=("best", "one_se"),
        default="one_se",
        help="one_se is more conservative; best chooses the lowest validation MAE.",
    )
    parser.add_argument(
        "--nonoverlap-spacing-ms",
        type=int,
        default=0,
        help="0 uses the model horizon. Used for fitting and validation.",
    )
    parser.add_argument("--direction-deadband-bps", type=float, default=0.05)
    parser.add_argument("--bootstrap-repetitions", type=int, default=5000)
    parser.add_argument("--bootstrap-block-markets", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--allow-mixed-models", action="store_true")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        result = run_backtest(args)
    except (BacktestError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    print(json.dumps(result, indent=2, sort_keys=True))
    print(f"\nWrote results to: {result['output_dir']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
